﻿using System;

namespace Bai2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ho ten cua ban: ");
            string hoTen = Console.ReadLine()!;
            Console.WriteLine("Chao ban {0}!", hoTen);
        }
    }
}
