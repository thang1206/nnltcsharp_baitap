﻿using System;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmKhachSan : Form
    {
        RadioButton[] rdoPhong;
        CheckBox[] chkTienNghi;

        int tongSoKhach = 0;
        long tongTien = 0;

        public FrmKhachSan()
        {
            InitializeComponent();
            rdoPhong = new[] { rdoPhongDon, rdoPhongDoi, rdoPhongBa };
            chkTienNghi = new[] { chkTivi, chkTuLanh, chkMayLanh, chkBonTam };
        }

        private void FrmKhachSan_Load(object sender, EventArgs e)
        {
            NhapMoi();
            btnTongKet.Enabled = false;
        }

        // Khởi tạo lại form để nhập khách mới
        private void NhapMoi()
        {
            txtTen.Clear();
            txtDiaChi.Clear();
            txtSoNgay.Clear();
            foreach (RadioButton r in rdoPhong) r.Checked = false;
            foreach (CheckBox c in chkTienNghi) c.Checked = false;
            chkKaraoke.Checked = false;
            chkAnSang.Checked = false;
            lblThanhTien.Text = "0 đ";
            btnThanhToan.Enabled = false;
            btnNhapMoi.Enabled = false;
            this.ActiveControl = txtTen;
            txtTen.Focus();
        }

        private int LoaiPhong()
        {
            for (int i = 0; i < rdoPhong.Length; i++)
                if (rdoPhong[i].Checked)
                    return i;
            return -1;
        }

        private bool DuThongTin()
        {
            int soNgay;
            return txtTen.Text.Trim() != ""
                && txtDiaChi.Text.Trim() != ""
                && int.TryParse(txtSoNgay.Text, out soNgay) && soNgay > 0
                && LoaiPhong() >= 0;
        }

        // Nhập đủ thông tin thì btnThanhToan có tác dụng
        private void ThongTin_Changed(object sender, EventArgs e)
        {
            btnThanhToan.Enabled = DuThongTin();
        }

        // Số ngày ở chỉ cho nhập số
        private void txtSoNgay_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (txtTen.Text.Trim() == "")
            {
                MessageBox.Show("Tên khách không được để trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTen.Focus();
                return;
            }
            int soNgay;
            if (!int.TryParse(txtSoNgay.Text, out soNgay) || soNgay <= 0)
            {
                MessageBox.Show("Số ngày ở phải là số nguyên lớn hơn 0!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSoNgay.Focus();
                return;
            }

            int soTienNghi = 0;
            foreach (CheckBox c in chkTienNghi)
                if (c.Checked) soTienNghi++;

            HoaDonKhachSan hd = new HoaDonKhachSan(txtTen.Text.Trim(), txtDiaChi.Text.Trim(), soNgay,
                LoaiPhong(), soTienNghi, chkKaraoke.Checked, chkAnSang.Checked);
            long tien = hd.ThanhTien();
            lblThanhTien.Text = tien.ToString("#,##0") + " đ";

            // Lưu lại tổng tiền và tổng lượt khách
            tongTien += tien;
            tongSoKhach++;

            btnThanhToan.Enabled = false;   // tránh tính tiền 2 lần cho cùng một khách
            btnNhapMoi.Enabled = true;
            btnTongKet.Enabled = true;
        }

        private void btnNhapMoi_Click(object sender, EventArgs e)
        {
            NhapMoi();
        }

        private void btnTongKet_Click(object sender, EventArgs e)
        {
            lblTongKhach.Text = tongSoKhach.ToString();
            lblTongTien.Text = tongTien.ToString("#,##0") + " đ";
            tongSoKhach = 0;
            tongTien = 0;
            btnTongKet.Enabled = false;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmKhachSan_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi chương trình?", "Thoát",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
