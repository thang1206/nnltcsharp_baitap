﻿namespace WinFormsThucHanh
{
    partial class FrmMang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpNhap = new System.Windows.Forms.GroupBox();
            this.lblNhap = new System.Windows.Forms.Label();
            this.txtNhapMang = new System.Windows.Forms.TextBox();
            this.btnTaoMang = new System.Windows.Forms.Button();
            this.lblN = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.btnNgauNhien = new System.Windows.Forms.Button();
            this.lblMang = new System.Windows.Forms.Label();
            this.txtMang = new System.Windows.Forms.TextBox();
            this.grpSapXep = new System.Windows.Forms.GroupBox();
            this.btnTang = new System.Windows.Forms.Button();
            this.btnGiam = new System.Windows.Forms.Button();
            this.grpTinh = new System.Windows.Forms.GroupBox();
            this.btnTong = new System.Windows.Forms.Button();
            this.btnTongChan = new System.Windows.Forms.Button();
            this.btnTongLe = new System.Windows.Forms.Button();
            this.btnMax = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            this.grpTim = new System.Windows.Forms.GroupBox();
            this.lblGiaTriTim = new System.Windows.Forms.Label();
            this.txtGiaTriTim = new System.Windows.Forms.TextBox();
            this.btnTimGiaTri = new System.Windows.Forms.Button();
            this.lblViTriTim = new System.Windows.Forms.Label();
            this.txtViTriTim = new System.Windows.Forms.TextBox();
            this.btnTimViTri = new System.Windows.Forms.Button();
            this.grpThem = new System.Windows.Forms.GroupBox();
            this.lblViTriThem = new System.Windows.Forms.Label();
            this.txtViTriThem = new System.Windows.Forms.TextBox();
            this.lblGiaTriThem = new System.Windows.Forms.Label();
            this.txtGiaTriThem = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.grpThay = new System.Windows.Forms.GroupBox();
            this.lblGiaTriCu = new System.Windows.Forms.Label();
            this.txtGiaTriCu = new System.Windows.Forms.TextBox();
            this.lblGiaTriMoi = new System.Windows.Forms.Label();
            this.txtGiaTriMoi = new System.Windows.Forms.TextBox();
            this.btnThayGiaTri = new System.Windows.Forms.Button();
            this.lblViTriThay = new System.Windows.Forms.Label();
            this.txtViTriThay = new System.Windows.Forms.TextBox();
            this.lblGiaTriMoi2 = new System.Windows.Forms.Label();
            this.txtGiaTriMoi2 = new System.Windows.Forms.TextBox();
            this.btnThayViTri = new System.Windows.Forms.Button();
            this.lblKetQua = new System.Windows.Forms.Label();
            this.txtKetQua = new System.Windows.Forms.TextBox();
            this.btnThoat = new System.Windows.Forms.Button();
            this.grpNhap.SuspendLayout();
            this.grpSapXep.SuspendLayout();
            this.grpTinh.SuspendLayout();
            this.grpTim.SuspendLayout();
            this.grpThem.SuspendLayout();
            this.grpThay.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(225, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Size = new System.Drawing.Size(0, 0);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "XỬ LÝ MẢNG MỘT CHIỀU";
            // 
            // grpNhap
            // 
            this.grpNhap.Controls.Add(this.lblNhap);
            this.grpNhap.Controls.Add(this.txtNhapMang);
            this.grpNhap.Controls.Add(this.btnTaoMang);
            this.grpNhap.Controls.Add(this.lblN);
            this.grpNhap.Controls.Add(this.txtN);
            this.grpNhap.Controls.Add(this.btnNgauNhien);
            this.grpNhap.Location = new System.Drawing.Point(15, 45);
            this.grpNhap.Name = "grpNhap";
            this.grpNhap.Size = new System.Drawing.Size(690, 90);
            this.grpNhap.TabIndex = 1;
            this.grpNhap.Text = "Nhập mảng";
            // 
            // lblNhap
            // 
            this.lblNhap.AutoSize = true;
            this.lblNhap.Location = new System.Drawing.Point(15, 25);
            this.lblNhap.Name = "lblNhap";
            this.lblNhap.Size = new System.Drawing.Size(300, 16);
            this.lblNhap.TabIndex = 0;
            this.lblNhap.Text = "Các phần tử (cách nhau bởi dấu cách):";
            // 
            // txtNhapMang
            // 
            this.txtNhapMang.Location = new System.Drawing.Point(15, 50);
            this.txtNhapMang.Name = "txtNhapMang";
            this.txtNhapMang.Size = new System.Drawing.Size(380, 22);
            this.txtNhapMang.TabIndex = 1;
            this.txtNhapMang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNhapMang_KeyPress);
            // 
            // btnTaoMang
            // 
            this.btnTaoMang.Location = new System.Drawing.Point(405, 46);
            this.btnTaoMang.Name = "btnTaoMang";
            this.btnTaoMang.Size = new System.Drawing.Size(95, 30);
            this.btnTaoMang.TabIndex = 2;
            this.btnTaoMang.Text = "Tạo mảng";
            this.btnTaoMang.UseVisualStyleBackColor = true;
            this.btnTaoMang.Click += new System.EventHandler(this.btnTaoMang_Click);
            // 
            // lblN
            // 
            this.lblN.AutoSize = true;
            this.lblN.Location = new System.Drawing.Point(510, 53);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(28, 16);
            this.lblN.TabIndex = 3;
            this.lblN.Text = "n =";
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(542, 50);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(40, 22);
            this.txtN.TabIndex = 4;
            this.txtN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // btnNgauNhien
            // 
            this.btnNgauNhien.Location = new System.Drawing.Point(590, 46);
            this.btnNgauNhien.Name = "btnNgauNhien";
            this.btnNgauNhien.Size = new System.Drawing.Size(90, 30);
            this.btnNgauNhien.TabIndex = 5;
            this.btnNgauNhien.Text = "Ngẫu nhiên";
            this.btnNgauNhien.UseVisualStyleBackColor = true;
            this.btnNgauNhien.Click += new System.EventHandler(this.btnNgauNhien_Click);
            // 
            // lblMang
            // 
            this.lblMang.AutoSize = true;
            this.lblMang.Location = new System.Drawing.Point(15, 151);
            this.lblMang.Name = "lblMang";
            this.lblMang.Size = new System.Drawing.Size(95, 16);
            this.lblMang.TabIndex = 2;
            this.lblMang.Text = "Mảng hiện tại:";
            // 
            // txtMang
            // 
            this.txtMang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMang.Location = new System.Drawing.Point(125, 148);
            this.txtMang.Name = "txtMang";
            this.txtMang.ReadOnly = true;
            this.txtMang.TabStop = false;
            this.txtMang.Size = new System.Drawing.Size(580, 22);
            this.txtMang.TabIndex = 3;
            // 
            // grpSapXep
            // 
            this.grpSapXep.Controls.Add(this.btnTang);
            this.grpSapXep.Controls.Add(this.btnGiam);
            this.grpSapXep.Location = new System.Drawing.Point(15, 182);
            this.grpSapXep.Name = "grpSapXep";
            this.grpSapXep.Size = new System.Drawing.Size(220, 70);
            this.grpSapXep.TabIndex = 4;
            this.grpSapXep.Text = "Sắp xếp";
            // 
            // btnTang
            // 
            this.btnTang.Location = new System.Drawing.Point(15, 27);
            this.btnTang.Name = "btnTang";
            this.btnTang.Size = new System.Drawing.Size(90, 30);
            this.btnTang.TabIndex = 0;
            this.btnTang.Text = "Tăng dần";
            this.btnTang.UseVisualStyleBackColor = true;
            this.btnTang.Click += new System.EventHandler(this.btnTang_Click);
            // 
            // btnGiam
            // 
            this.btnGiam.Location = new System.Drawing.Point(115, 27);
            this.btnGiam.Name = "btnGiam";
            this.btnGiam.Size = new System.Drawing.Size(90, 30);
            this.btnGiam.TabIndex = 1;
            this.btnGiam.Text = "Giảm dần";
            this.btnGiam.UseVisualStyleBackColor = true;
            this.btnGiam.Click += new System.EventHandler(this.btnGiam_Click);
            // 
            // grpTinh
            // 
            this.grpTinh.Controls.Add(this.btnTong);
            this.grpTinh.Controls.Add(this.btnTongChan);
            this.grpTinh.Controls.Add(this.btnTongLe);
            this.grpTinh.Controls.Add(this.btnMax);
            this.grpTinh.Controls.Add(this.btnMin);
            this.grpTinh.Location = new System.Drawing.Point(245, 182);
            this.grpTinh.Name = "grpTinh";
            this.grpTinh.Size = new System.Drawing.Size(460, 70);
            this.grpTinh.TabIndex = 5;
            this.grpTinh.Text = "Tính toán";
            // 
            // btnTong
            // 
            this.btnTong.Location = new System.Drawing.Point(15, 27);
            this.btnTong.Name = "btnTong";
            this.btnTong.Size = new System.Drawing.Size(75, 30);
            this.btnTong.TabIndex = 0;
            this.btnTong.Text = "Tổng";
            this.btnTong.UseVisualStyleBackColor = true;
            this.btnTong.Click += new System.EventHandler(this.btnTong_Click);
            // 
            // btnTongChan
            // 
            this.btnTongChan.Location = new System.Drawing.Point(95, 27);
            this.btnTongChan.Name = "btnTongChan";
            this.btnTongChan.Size = new System.Drawing.Size(90, 30);
            this.btnTongChan.TabIndex = 1;
            this.btnTongChan.Text = "Tổng chẵn";
            this.btnTongChan.UseVisualStyleBackColor = true;
            this.btnTongChan.Click += new System.EventHandler(this.btnTongChan_Click);
            // 
            // btnTongLe
            // 
            this.btnTongLe.Location = new System.Drawing.Point(190, 27);
            this.btnTongLe.Name = "btnTongLe";
            this.btnTongLe.Size = new System.Drawing.Size(80, 30);
            this.btnTongLe.TabIndex = 2;
            this.btnTongLe.Text = "Tổng lẻ";
            this.btnTongLe.UseVisualStyleBackColor = true;
            this.btnTongLe.Click += new System.EventHandler(this.btnTongLe_Click);
            // 
            // btnMax
            // 
            this.btnMax.Location = new System.Drawing.Point(275, 27);
            this.btnMax.Name = "btnMax";
            this.btnMax.Size = new System.Drawing.Size(85, 30);
            this.btnMax.TabIndex = 3;
            this.btnMax.Text = "Lớn nhất";
            this.btnMax.UseVisualStyleBackColor = true;
            this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
            // 
            // btnMin
            // 
            this.btnMin.Location = new System.Drawing.Point(365, 27);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(85, 30);
            this.btnMin.TabIndex = 4;
            this.btnMin.Text = "Nhỏ nhất";
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // grpTim
            // 
            this.grpTim.Controls.Add(this.lblGiaTriTim);
            this.grpTim.Controls.Add(this.txtGiaTriTim);
            this.grpTim.Controls.Add(this.btnTimGiaTri);
            this.grpTim.Controls.Add(this.lblViTriTim);
            this.grpTim.Controls.Add(this.txtViTriTim);
            this.grpTim.Controls.Add(this.btnTimViTri);
            this.grpTim.Location = new System.Drawing.Point(15, 262);
            this.grpTim.Name = "grpTim";
            this.grpTim.Size = new System.Drawing.Size(340, 95);
            this.grpTim.TabIndex = 6;
            this.grpTim.Text = "Tìm kiếm";
            // 
            // lblGiaTriTim
            // 
            this.lblGiaTriTim.AutoSize = true;
            this.lblGiaTriTim.Location = new System.Drawing.Point(15, 30);
            this.lblGiaTriTim.Name = "lblGiaTriTim";
            this.lblGiaTriTim.Size = new System.Drawing.Size(55, 16);
            this.lblGiaTriTim.TabIndex = 0;
            this.lblGiaTriTim.Text = "Giá trị:";
            // 
            // txtGiaTriTim
            // 
            this.txtGiaTriTim.Location = new System.Drawing.Point(115, 27);
            this.txtGiaTriTim.Name = "txtGiaTriTim";
            this.txtGiaTriTim.Size = new System.Drawing.Size(80, 22);
            this.txtGiaTriTim.TabIndex = 1;
            this.txtGiaTriTim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // btnTimGiaTri
            // 
            this.btnTimGiaTri.Location = new System.Drawing.Point(205, 23);
            this.btnTimGiaTri.Name = "btnTimGiaTri";
            this.btnTimGiaTri.Size = new System.Drawing.Size(120, 30);
            this.btnTimGiaTri.TabIndex = 2;
            this.btnTimGiaTri.Text = "Tìm vị trí";
            this.btnTimGiaTri.UseVisualStyleBackColor = true;
            this.btnTimGiaTri.Click += new System.EventHandler(this.btnTimGiaTri_Click);
            // 
            // lblViTriTim
            // 
            this.lblViTriTim.AutoSize = true;
            this.lblViTriTim.Location = new System.Drawing.Point(15, 63);
            this.lblViTriTim.Name = "lblViTriTim";
            this.lblViTriTim.Size = new System.Drawing.Size(90, 16);
            this.lblViTriTim.TabIndex = 3;
            this.lblViTriTim.Text = "Vị trí (từ 0):";
            // 
            // txtViTriTim
            // 
            this.txtViTriTim.Location = new System.Drawing.Point(115, 60);
            this.txtViTriTim.Name = "txtViTriTim";
            this.txtViTriTim.Size = new System.Drawing.Size(80, 22);
            this.txtViTriTim.TabIndex = 4;
            this.txtViTriTim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // btnTimViTri
            // 
            this.btnTimViTri.Location = new System.Drawing.Point(205, 56);
            this.btnTimViTri.Name = "btnTimViTri";
            this.btnTimViTri.Size = new System.Drawing.Size(120, 30);
            this.btnTimViTri.TabIndex = 5;
            this.btnTimViTri.Text = "Lấy giá trị";
            this.btnTimViTri.UseVisualStyleBackColor = true;
            this.btnTimViTri.Click += new System.EventHandler(this.btnTimViTri_Click);
            // 
            // grpThem
            // 
            this.grpThem.Controls.Add(this.lblViTriThem);
            this.grpThem.Controls.Add(this.txtViTriThem);
            this.grpThem.Controls.Add(this.lblGiaTriThem);
            this.grpThem.Controls.Add(this.txtGiaTriThem);
            this.grpThem.Controls.Add(this.btnThem);
            this.grpThem.Location = new System.Drawing.Point(365, 262);
            this.grpThem.Name = "grpThem";
            this.grpThem.Size = new System.Drawing.Size(340, 95);
            this.grpThem.TabIndex = 7;
            this.grpThem.Text = "Thêm phần tử";
            // 
            // lblViTriThem
            // 
            this.lblViTriThem.AutoSize = true;
            this.lblViTriThem.Location = new System.Drawing.Point(15, 30);
            this.lblViTriThem.Name = "lblViTriThem";
            this.lblViTriThem.Size = new System.Drawing.Size(90, 16);
            this.lblViTriThem.TabIndex = 0;
            this.lblViTriThem.Text = "Vị trí (từ 0):";
            // 
            // txtViTriThem
            // 
            this.txtViTriThem.Location = new System.Drawing.Point(115, 27);
            this.txtViTriThem.Name = "txtViTriThem";
            this.txtViTriThem.Size = new System.Drawing.Size(80, 22);
            this.txtViTriThem.TabIndex = 1;
            this.txtViTriThem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // lblGiaTriThem
            // 
            this.lblGiaTriThem.AutoSize = true;
            this.lblGiaTriThem.Location = new System.Drawing.Point(15, 63);
            this.lblGiaTriThem.Name = "lblGiaTriThem";
            this.lblGiaTriThem.Size = new System.Drawing.Size(55, 16);
            this.lblGiaTriThem.TabIndex = 2;
            this.lblGiaTriThem.Text = "Giá trị:";
            // 
            // txtGiaTriThem
            // 
            this.txtGiaTriThem.Location = new System.Drawing.Point(115, 60);
            this.txtGiaTriThem.Name = "txtGiaTriThem";
            this.txtGiaTriThem.Size = new System.Drawing.Size(80, 22);
            this.txtGiaTriThem.TabIndex = 3;
            this.txtGiaTriThem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(205, 38);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(120, 32);
            this.btnThem.TabIndex = 4;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // grpThay
            // 
            this.grpThay.Controls.Add(this.lblGiaTriCu);
            this.grpThay.Controls.Add(this.txtGiaTriCu);
            this.grpThay.Controls.Add(this.lblGiaTriMoi);
            this.grpThay.Controls.Add(this.txtGiaTriMoi);
            this.grpThay.Controls.Add(this.btnThayGiaTri);
            this.grpThay.Controls.Add(this.lblViTriThay);
            this.grpThay.Controls.Add(this.txtViTriThay);
            this.grpThay.Controls.Add(this.lblGiaTriMoi2);
            this.grpThay.Controls.Add(this.txtGiaTriMoi2);
            this.grpThay.Controls.Add(this.btnThayViTri);
            this.grpThay.Location = new System.Drawing.Point(15, 367);
            this.grpThay.Name = "grpThay";
            this.grpThay.Size = new System.Drawing.Size(690, 95);
            this.grpThay.TabIndex = 8;
            this.grpThay.Text = "Thay thế";
            // 
            // lblGiaTriCu
            // 
            this.lblGiaTriCu.AutoSize = true;
            this.lblGiaTriCu.Location = new System.Drawing.Point(15, 30);
            this.lblGiaTriCu.Name = "lblGiaTriCu";
            this.lblGiaTriCu.Size = new System.Drawing.Size(75, 16);
            this.lblGiaTriCu.TabIndex = 0;
            this.lblGiaTriCu.Text = "Giá trị cũ:";
            // 
            // txtGiaTriCu
            // 
            this.txtGiaTriCu.Location = new System.Drawing.Point(115, 27);
            this.txtGiaTriCu.Name = "txtGiaTriCu";
            this.txtGiaTriCu.Size = new System.Drawing.Size(80, 22);
            this.txtGiaTriCu.TabIndex = 1;
            this.txtGiaTriCu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // lblGiaTriMoi
            // 
            this.lblGiaTriMoi.AutoSize = true;
            this.lblGiaTriMoi.Location = new System.Drawing.Point(215, 30);
            this.lblGiaTriMoi.Name = "lblGiaTriMoi";
            this.lblGiaTriMoi.Size = new System.Drawing.Size(80, 16);
            this.lblGiaTriMoi.TabIndex = 2;
            this.lblGiaTriMoi.Text = "Giá trị mới:";
            // 
            // txtGiaTriMoi
            // 
            this.txtGiaTriMoi.Location = new System.Drawing.Point(305, 27);
            this.txtGiaTriMoi.Name = "txtGiaTriMoi";
            this.txtGiaTriMoi.Size = new System.Drawing.Size(80, 22);
            this.txtGiaTriMoi.TabIndex = 3;
            this.txtGiaTriMoi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // btnThayGiaTri
            // 
            this.btnThayGiaTri.Location = new System.Drawing.Point(405, 23);
            this.btnThayGiaTri.Name = "btnThayGiaTri";
            this.btnThayGiaTri.Size = new System.Drawing.Size(170, 30);
            this.btnThayGiaTri.TabIndex = 4;
            this.btnThayGiaTri.Text = "Thay theo giá trị";
            this.btnThayGiaTri.UseVisualStyleBackColor = true;
            this.btnThayGiaTri.Click += new System.EventHandler(this.btnThayGiaTri_Click);
            // 
            // lblViTriThay
            // 
            this.lblViTriThay.AutoSize = true;
            this.lblViTriThay.Location = new System.Drawing.Point(15, 63);
            this.lblViTriThay.Name = "lblViTriThay";
            this.lblViTriThay.Size = new System.Drawing.Size(90, 16);
            this.lblViTriThay.TabIndex = 5;
            this.lblViTriThay.Text = "Vị trí (từ 0):";
            // 
            // txtViTriThay
            // 
            this.txtViTriThay.Location = new System.Drawing.Point(115, 60);
            this.txtViTriThay.Name = "txtViTriThay";
            this.txtViTriThay.Size = new System.Drawing.Size(80, 22);
            this.txtViTriThay.TabIndex = 6;
            this.txtViTriThay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // lblGiaTriMoi2
            // 
            this.lblGiaTriMoi2.AutoSize = true;
            this.lblGiaTriMoi2.Location = new System.Drawing.Point(215, 63);
            this.lblGiaTriMoi2.Name = "lblGiaTriMoi2";
            this.lblGiaTriMoi2.Size = new System.Drawing.Size(80, 16);
            this.lblGiaTriMoi2.TabIndex = 7;
            this.lblGiaTriMoi2.Text = "Giá trị mới:";
            // 
            // txtGiaTriMoi2
            // 
            this.txtGiaTriMoi2.Location = new System.Drawing.Point(305, 60);
            this.txtGiaTriMoi2.Name = "txtGiaTriMoi2";
            this.txtGiaTriMoi2.Size = new System.Drawing.Size(80, 22);
            this.txtGiaTriMoi2.TabIndex = 8;
            this.txtGiaTriMoi2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNguyen_KeyPress);
            // 
            // btnThayViTri
            // 
            this.btnThayViTri.Location = new System.Drawing.Point(405, 56);
            this.btnThayViTri.Name = "btnThayViTri";
            this.btnThayViTri.Size = new System.Drawing.Size(170, 30);
            this.btnThayViTri.TabIndex = 9;
            this.btnThayViTri.Text = "Thay theo vị trí";
            this.btnThayViTri.UseVisualStyleBackColor = true;
            this.btnThayViTri.Click += new System.EventHandler(this.btnThayViTri_Click);
            // 
            // lblKetQua
            // 
            this.lblKetQua.AutoSize = true;
            this.lblKetQua.Location = new System.Drawing.Point(15, 480);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(65, 16);
            this.lblKetQua.TabIndex = 9;
            this.lblKetQua.Text = "Kết quả:";
            // 
            // txtKetQua
            // 
            this.txtKetQua.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKetQua.Location = new System.Drawing.Point(90, 477);
            this.txtKetQua.Name = "txtKetQua";
            this.txtKetQua.ReadOnly = true;
            this.txtKetQua.TabStop = false;
            this.txtKetQua.ForeColor = System.Drawing.Color.Blue;
            this.txtKetQua.Size = new System.Drawing.Size(500, 22);
            this.txtKetQua.TabIndex = 10;
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(605, 472);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(100, 32);
            this.btnThoat.TabIndex = 11;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 520);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpNhap);
            this.Controls.Add(this.lblMang);
            this.Controls.Add(this.txtMang);
            this.Controls.Add(this.grpSapXep);
            this.Controls.Add(this.grpTinh);
            this.Controls.Add(this.grpTim);
            this.Controls.Add(this.grpThem);
            this.Controls.Add(this.grpThay);
            this.Controls.Add(this.lblKetQua);
            this.Controls.Add(this.txtKetQua);
            this.Controls.Add(this.btnThoat);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmMang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài tại lớp 2 - Mảng một chiều";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMang_FormClosing);
            this.grpNhap.ResumeLayout(false);
            this.grpNhap.PerformLayout();
            this.grpSapXep.ResumeLayout(false);
            this.grpSapXep.PerformLayout();
            this.grpTinh.ResumeLayout(false);
            this.grpTinh.PerformLayout();
            this.grpTim.ResumeLayout(false);
            this.grpTim.PerformLayout();
            this.grpThem.ResumeLayout(false);
            this.grpThem.PerformLayout();
            this.grpThay.ResumeLayout(false);
            this.grpThay.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpNhap;
        private System.Windows.Forms.Label lblNhap;
        private System.Windows.Forms.TextBox txtNhapMang;
        private System.Windows.Forms.Button btnTaoMang;
        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Button btnNgauNhien;
        private System.Windows.Forms.Label lblMang;
        private System.Windows.Forms.TextBox txtMang;
        private System.Windows.Forms.GroupBox grpSapXep;
        private System.Windows.Forms.Button btnTang;
        private System.Windows.Forms.Button btnGiam;
        private System.Windows.Forms.GroupBox grpTinh;
        private System.Windows.Forms.Button btnTong;
        private System.Windows.Forms.Button btnTongChan;
        private System.Windows.Forms.Button btnTongLe;
        private System.Windows.Forms.Button btnMax;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.GroupBox grpTim;
        private System.Windows.Forms.Label lblGiaTriTim;
        private System.Windows.Forms.TextBox txtGiaTriTim;
        private System.Windows.Forms.Button btnTimGiaTri;
        private System.Windows.Forms.Label lblViTriTim;
        private System.Windows.Forms.TextBox txtViTriTim;
        private System.Windows.Forms.Button btnTimViTri;
        private System.Windows.Forms.GroupBox grpThem;
        private System.Windows.Forms.Label lblViTriThem;
        private System.Windows.Forms.TextBox txtViTriThem;
        private System.Windows.Forms.Label lblGiaTriThem;
        private System.Windows.Forms.TextBox txtGiaTriThem;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.GroupBox grpThay;
        private System.Windows.Forms.Label lblGiaTriCu;
        private System.Windows.Forms.TextBox txtGiaTriCu;
        private System.Windows.Forms.Label lblGiaTriMoi;
        private System.Windows.Forms.TextBox txtGiaTriMoi;
        private System.Windows.Forms.Button btnThayGiaTri;
        private System.Windows.Forms.Label lblViTriThay;
        private System.Windows.Forms.TextBox txtViTriThay;
        private System.Windows.Forms.Label lblGiaTriMoi2;
        private System.Windows.Forms.TextBox txtGiaTriMoi2;
        private System.Windows.Forms.Button btnThayViTri;
        private System.Windows.Forms.Label lblKetQua;
        private System.Windows.Forms.TextBox txtKetQua;
        private System.Windows.Forms.Button btnThoat;
    }
}
