﻿namespace WinFormsThucHanh
{
    partial class FrmDinhDang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNoiDung = new System.Windows.Forms.Label();
            this.grpFontStyle = new System.Windows.Forms.GroupBox();
            this.chkBold = new System.Windows.Forms.CheckBox();
            this.chkItalic = new System.Windows.Forms.CheckBox();
            this.chkUnderline = new System.Windows.Forms.CheckBox();
            this.grpColor = new System.Windows.Forms.GroupBox();
            this.rdoRed = new System.Windows.Forms.RadioButton();
            this.rdoGreen = new System.Windows.Forms.RadioButton();
            this.rdoBlue = new System.Windows.Forms.RadioButton();
            this.rdoBlack = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpFontStyle.SuspendLayout();
            this.grpColor.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNoiDung
            // 
            this.lblNoiDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoiDung.Location = new System.Drawing.Point(30, 20);
            this.lblNoiDung.Name = "lblNoiDung";
            this.lblNoiDung.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNoiDung.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblNoiDung.Size = new System.Drawing.Size(400, 55);
            this.lblNoiDung.TabIndex = 0;
            this.lblNoiDung.Text = "Khoa Công Nghệ Thông Tin";
            // 
            // grpFontStyle
            // 
            this.grpFontStyle.Controls.Add(this.chkBold);
            this.grpFontStyle.Controls.Add(this.chkItalic);
            this.grpFontStyle.Controls.Add(this.chkUnderline);
            this.grpFontStyle.Location = new System.Drawing.Point(30, 95);
            this.grpFontStyle.Name = "grpFontStyle";
            this.grpFontStyle.Size = new System.Drawing.Size(190, 150);
            this.grpFontStyle.TabIndex = 1;
            this.grpFontStyle.Text = "Font Style";
            // 
            // chkBold
            // 
            this.chkBold.AutoSize = true;
            this.chkBold.Location = new System.Drawing.Point(20, 30);
            this.chkBold.Name = "chkBold";
            this.chkBold.Size = new System.Drawing.Size(55, 20);
            this.chkBold.TabIndex = 0;
            this.chkBold.Text = "Bold";
            this.chkBold.CheckedChanged += new System.EventHandler(this.chkFontStyle_CheckedChanged);
            // 
            // chkItalic
            // 
            this.chkItalic.AutoSize = true;
            this.chkItalic.Location = new System.Drawing.Point(20, 65);
            this.chkItalic.Name = "chkItalic";
            this.chkItalic.Size = new System.Drawing.Size(55, 20);
            this.chkItalic.TabIndex = 1;
            this.chkItalic.Text = "Italic";
            this.chkItalic.CheckedChanged += new System.EventHandler(this.chkFontStyle_CheckedChanged);
            // 
            // chkUnderline
            // 
            this.chkUnderline.AutoSize = true;
            this.chkUnderline.Location = new System.Drawing.Point(20, 100);
            this.chkUnderline.Name = "chkUnderline";
            this.chkUnderline.Size = new System.Drawing.Size(85, 20);
            this.chkUnderline.TabIndex = 2;
            this.chkUnderline.Text = "Underline";
            this.chkUnderline.CheckedChanged += new System.EventHandler(this.chkFontStyle_CheckedChanged);
            // 
            // grpColor
            // 
            this.grpColor.Controls.Add(this.rdoRed);
            this.grpColor.Controls.Add(this.rdoGreen);
            this.grpColor.Controls.Add(this.rdoBlue);
            this.grpColor.Controls.Add(this.rdoBlack);
            this.grpColor.Location = new System.Drawing.Point(240, 95);
            this.grpColor.Name = "grpColor";
            this.grpColor.Size = new System.Drawing.Size(190, 150);
            this.grpColor.TabIndex = 2;
            this.grpColor.Text = "Color";
            // 
            // rdoRed
            // 
            this.rdoRed.AutoSize = true;
            this.rdoRed.Location = new System.Drawing.Point(20, 27);
            this.rdoRed.Name = "rdoRed";
            this.rdoRed.Size = new System.Drawing.Size(50, 20);
            this.rdoRed.TabIndex = 0;
            this.rdoRed.Text = "Red";
            this.rdoRed.CheckedChanged += new System.EventHandler(this.rdo_red_CheckedChanged);
            // 
            // rdoGreen
            // 
            this.rdoGreen.AutoSize = true;
            this.rdoGreen.Location = new System.Drawing.Point(20, 55);
            this.rdoGreen.Name = "rdoGreen";
            this.rdoGreen.Size = new System.Drawing.Size(60, 20);
            this.rdoGreen.TabIndex = 1;
            this.rdoGreen.Text = "Green";
            this.rdoGreen.CheckedChanged += new System.EventHandler(this.rdo_green_CheckedChanged);
            // 
            // rdoBlue
            // 
            this.rdoBlue.AutoSize = true;
            this.rdoBlue.Location = new System.Drawing.Point(20, 83);
            this.rdoBlue.Name = "rdoBlue";
            this.rdoBlue.Size = new System.Drawing.Size(50, 20);
            this.rdoBlue.TabIndex = 2;
            this.rdoBlue.Text = "Blue";
            this.rdoBlue.CheckedChanged += new System.EventHandler(this.rdo_blue_CheckedChanged);
            // 
            // rdoBlack
            // 
            this.rdoBlack.AutoSize = true;
            this.rdoBlack.Location = new System.Drawing.Point(20, 111);
            this.rdoBlack.Name = "rdoBlack";
            this.rdoBlack.Checked = true;
            this.rdoBlack.TabStop = true;
            this.rdoBlack.Size = new System.Drawing.Size(55, 20);
            this.rdoBlack.TabIndex = 3;
            this.rdoBlack.Text = "Black";
            this.rdoBlack.CheckedChanged += new System.EventHandler(this.rdo_black_CheckedChanged);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(180, 262);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 32);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // FrmDinhDang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 310);
            this.Controls.Add(this.lblNoiDung);
            this.Controls.Add(this.grpFontStyle);
            this.Controls.Add(this.grpColor);
            this.Controls.Add(this.btnExit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmDinhDang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài mẫu 2 - Định dạng Label";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmDinhDang_FormClosing);
            this.grpFontStyle.ResumeLayout(false);
            this.grpFontStyle.PerformLayout();
            this.grpColor.ResumeLayout(false);
            this.grpColor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNoiDung;
        private System.Windows.Forms.GroupBox grpFontStyle;
        private System.Windows.Forms.CheckBox chkBold;
        private System.Windows.Forms.CheckBox chkItalic;
        private System.Windows.Forms.CheckBox chkUnderline;
        private System.Windows.Forms.GroupBox grpColor;
        private System.Windows.Forms.RadioButton rdoRed;
        private System.Windows.Forms.RadioButton rdoGreen;
        private System.Windows.Forms.RadioButton rdoBlue;
        private System.Windows.Forms.RadioButton rdoBlack;
        private System.Windows.Forms.Button btnExit;
    }
}
