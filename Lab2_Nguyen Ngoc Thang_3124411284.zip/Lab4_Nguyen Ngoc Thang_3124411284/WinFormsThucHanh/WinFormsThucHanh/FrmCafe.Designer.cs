﻿namespace WinFormsThucHanh
{
    partial class FrmCafe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpKhach = new System.Windows.Forms.GroupBox();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.txtTenKH = new System.Windows.Forms.TextBox();
            this.lblSoKhach = new System.Windows.Forms.Label();
            this.txtSoKhach = new System.Windows.Forms.TextBox();
            this.chkSinhVien = new System.Windows.Forms.CheckBox();
            this.grpNuocUong = new System.Windows.Forms.GroupBox();
            this.rdoCafeDen = new System.Windows.Forms.RadioButton();
            this.rdoCafeDa = new System.Windows.Forms.RadioButton();
            this.rdoCafeSua = new System.Windows.Forms.RadioButton();
            this.rdoCafeSuaDa = new System.Windows.Forms.RadioButton();
            this.rdoCafeKem = new System.Windows.Forms.RadioButton();
            this.grpThucAn = new System.Windows.Forms.GroupBox();
            this.rdoBanhMyTrung = new System.Windows.Forms.RadioButton();
            this.rdoBanhMyCa = new System.Windows.Forms.RadioButton();
            this.rdoMyTomTrung = new System.Windows.Forms.RadioButton();
            this.rdoMyXaoBo = new System.Windows.Forms.RadioButton();
            this.rdoMyCay = new System.Windows.Forms.RadioButton();
            this.btnTinhTien = new System.Windows.Forms.Button();
            this.btnNhapLai = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.grpThongKe = new System.Windows.Forms.GroupBox();
            this.lblTKKhach = new System.Windows.Forms.Label();
            this.lblTongKhach = new System.Windows.Forms.Label();
            this.lblTKTien = new System.Windows.Forms.Label();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.grpKhach.SuspendLayout();
            this.grpNuocUong.SuspendLayout();
            this.grpThucAn.SuspendLayout();
            this.grpThongKe.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(190, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Size = new System.Drawing.Size(0, 0);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUÁN CAFE SINH VIÊN";
            // 
            // grpKhach
            // 
            this.grpKhach.Controls.Add(this.lblTenKH);
            this.grpKhach.Controls.Add(this.txtTenKH);
            this.grpKhach.Controls.Add(this.lblSoKhach);
            this.grpKhach.Controls.Add(this.txtSoKhach);
            this.grpKhach.Controls.Add(this.chkSinhVien);
            this.grpKhach.Location = new System.Drawing.Point(15, 50);
            this.grpKhach.Name = "grpKhach";
            this.grpKhach.Size = new System.Drawing.Size(610, 70);
            this.grpKhach.TabIndex = 1;
            this.grpKhach.Text = "Thông tin khách hàng";
            // 
            // lblTenKH
            // 
            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Location = new System.Drawing.Point(15, 31);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(110, 16);
            this.lblTenKH.TabIndex = 0;
            this.lblTenKH.Text = "Tên khách hàng:";
            // 
            // txtTenKH
            // 
            this.txtTenKH.Location = new System.Drawing.Point(130, 28);
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(200, 22);
            this.txtTenKH.TabIndex = 1;
            this.txtTenKH.TextChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // lblSoKhach
            // 
            this.lblSoKhach.AutoSize = true;
            this.lblSoKhach.Location = new System.Drawing.Point(345, 31);
            this.lblSoKhach.Name = "lblSoKhach";
            this.lblSoKhach.Size = new System.Drawing.Size(70, 16);
            this.lblSoKhach.TabIndex = 2;
            this.lblSoKhach.Text = "Số khách:";
            // 
            // txtSoKhach
            // 
            this.txtSoKhach.Location = new System.Drawing.Point(420, 28);
            this.txtSoKhach.Name = "txtSoKhach";
            this.txtSoKhach.Size = new System.Drawing.Size(60, 22);
            this.txtSoKhach.TabIndex = 3;
            this.txtSoKhach.TextChanged += new System.EventHandler(this.ThongTin_Changed);
            this.txtSoKhach.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoKhach_KeyPress);
            // 
            // chkSinhVien
            // 
            this.chkSinhVien.AutoSize = true;
            this.chkSinhVien.Location = new System.Drawing.Point(500, 30);
            this.chkSinhVien.Name = "chkSinhVien";
            this.chkSinhVien.Size = new System.Drawing.Size(85, 20);
            this.chkSinhVien.TabIndex = 4;
            this.chkSinhVien.Text = "Sinh viên";
            this.chkSinhVien.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // grpNuocUong
            // 
            this.grpNuocUong.Controls.Add(this.rdoCafeDen);
            this.grpNuocUong.Controls.Add(this.rdoCafeDa);
            this.grpNuocUong.Controls.Add(this.rdoCafeSua);
            this.grpNuocUong.Controls.Add(this.rdoCafeSuaDa);
            this.grpNuocUong.Controls.Add(this.rdoCafeKem);
            this.grpNuocUong.Location = new System.Drawing.Point(15, 130);
            this.grpNuocUong.Name = "grpNuocUong";
            this.grpNuocUong.Size = new System.Drawing.Size(300, 180);
            this.grpNuocUong.TabIndex = 2;
            this.grpNuocUong.Text = "Nước uống";
            // 
            // rdoCafeDen
            // 
            this.rdoCafeDen.AutoSize = true;
            this.rdoCafeDen.Location = new System.Drawing.Point(20, 27);
            this.rdoCafeDen.Name = "rdoCafeDen";
            this.rdoCafeDen.Size = new System.Drawing.Size(200, 20);
            this.rdoCafeDen.TabIndex = 0;
            this.rdoCafeDen.Text = "Cafe đen (20.000đ)";
            this.rdoCafeDen.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoCafeDa
            // 
            this.rdoCafeDa.AutoSize = true;
            this.rdoCafeDa.Location = new System.Drawing.Point(20, 57);
            this.rdoCafeDa.Name = "rdoCafeDa";
            this.rdoCafeDa.Size = new System.Drawing.Size(200, 20);
            this.rdoCafeDa.TabIndex = 1;
            this.rdoCafeDa.Text = "Cafe đá (25.000đ)";
            this.rdoCafeDa.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoCafeSua
            // 
            this.rdoCafeSua.AutoSize = true;
            this.rdoCafeSua.Location = new System.Drawing.Point(20, 87);
            this.rdoCafeSua.Name = "rdoCafeSua";
            this.rdoCafeSua.Size = new System.Drawing.Size(200, 20);
            this.rdoCafeSua.TabIndex = 2;
            this.rdoCafeSua.Text = "Cafe sữa (25.000đ)";
            this.rdoCafeSua.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoCafeSuaDa
            // 
            this.rdoCafeSuaDa.AutoSize = true;
            this.rdoCafeSuaDa.Location = new System.Drawing.Point(20, 117);
            this.rdoCafeSuaDa.Name = "rdoCafeSuaDa";
            this.rdoCafeSuaDa.Size = new System.Drawing.Size(200, 20);
            this.rdoCafeSuaDa.TabIndex = 3;
            this.rdoCafeSuaDa.Text = "Cafe sữa đá (30.000đ)";
            this.rdoCafeSuaDa.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoCafeKem
            // 
            this.rdoCafeKem.AutoSize = true;
            this.rdoCafeKem.Location = new System.Drawing.Point(20, 147);
            this.rdoCafeKem.Name = "rdoCafeKem";
            this.rdoCafeKem.Size = new System.Drawing.Size(200, 20);
            this.rdoCafeKem.TabIndex = 4;
            this.rdoCafeKem.Text = "Cafe kem (35.000đ)";
            this.rdoCafeKem.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // grpThucAn
            // 
            this.grpThucAn.Controls.Add(this.rdoBanhMyTrung);
            this.grpThucAn.Controls.Add(this.rdoBanhMyCa);
            this.grpThucAn.Controls.Add(this.rdoMyTomTrung);
            this.grpThucAn.Controls.Add(this.rdoMyXaoBo);
            this.grpThucAn.Controls.Add(this.rdoMyCay);
            this.grpThucAn.Location = new System.Drawing.Point(325, 130);
            this.grpThucAn.Name = "grpThucAn";
            this.grpThucAn.Size = new System.Drawing.Size(300, 180);
            this.grpThucAn.TabIndex = 3;
            this.grpThucAn.Text = "Thức ăn";
            // 
            // rdoBanhMyTrung
            // 
            this.rdoBanhMyTrung.AutoSize = true;
            this.rdoBanhMyTrung.Location = new System.Drawing.Point(20, 27);
            this.rdoBanhMyTrung.Name = "rdoBanhMyTrung";
            this.rdoBanhMyTrung.Size = new System.Drawing.Size(200, 20);
            this.rdoBanhMyTrung.TabIndex = 0;
            this.rdoBanhMyTrung.Text = "Bánh mỳ trứng (15.000đ)";
            this.rdoBanhMyTrung.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoBanhMyCa
            // 
            this.rdoBanhMyCa.AutoSize = true;
            this.rdoBanhMyCa.Location = new System.Drawing.Point(20, 57);
            this.rdoBanhMyCa.Name = "rdoBanhMyCa";
            this.rdoBanhMyCa.Size = new System.Drawing.Size(200, 20);
            this.rdoBanhMyCa.TabIndex = 1;
            this.rdoBanhMyCa.Text = "Bánh mỳ cá (15.000đ)";
            this.rdoBanhMyCa.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoMyTomTrung
            // 
            this.rdoMyTomTrung.AutoSize = true;
            this.rdoMyTomTrung.Location = new System.Drawing.Point(20, 87);
            this.rdoMyTomTrung.Name = "rdoMyTomTrung";
            this.rdoMyTomTrung.Size = new System.Drawing.Size(200, 20);
            this.rdoMyTomTrung.TabIndex = 2;
            this.rdoMyTomTrung.Text = "Mỳ tôm trứng (20.000đ)";
            this.rdoMyTomTrung.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoMyXaoBo
            // 
            this.rdoMyXaoBo.AutoSize = true;
            this.rdoMyXaoBo.Location = new System.Drawing.Point(20, 117);
            this.rdoMyXaoBo.Name = "rdoMyXaoBo";
            this.rdoMyXaoBo.Size = new System.Drawing.Size(200, 20);
            this.rdoMyXaoBo.TabIndex = 3;
            this.rdoMyXaoBo.Text = "Mỳ xào bò (30.000đ)";
            this.rdoMyXaoBo.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoMyCay
            // 
            this.rdoMyCay.AutoSize = true;
            this.rdoMyCay.Location = new System.Drawing.Point(20, 147);
            this.rdoMyCay.Name = "rdoMyCay";
            this.rdoMyCay.Size = new System.Drawing.Size(200, 20);
            this.rdoMyCay.TabIndex = 4;
            this.rdoMyCay.Text = "Mỳ cay (50.000đ)";
            this.rdoMyCay.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // btnTinhTien
            // 
            this.btnTinhTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinhTien.Location = new System.Drawing.Point(15, 322);
            this.btnTinhTien.Name = "btnTinhTien";
            this.btnTinhTien.Size = new System.Drawing.Size(140, 36);
            this.btnTinhTien.TabIndex = 4;
            this.btnTinhTien.Text = "Tính tiền";
            this.btnTinhTien.UseVisualStyleBackColor = true;
            this.btnTinhTien.Click += new System.EventHandler(this.btnTinhTien_Click);
            // 
            // btnNhapLai
            // 
            this.btnNhapLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapLai.Location = new System.Drawing.Point(172, 322);
            this.btnNhapLai.Name = "btnNhapLai";
            this.btnNhapLai.Size = new System.Drawing.Size(140, 36);
            this.btnNhapLai.TabIndex = 5;
            this.btnNhapLai.Text = "Nhập lại";
            this.btnNhapLai.UseVisualStyleBackColor = true;
            this.btnNhapLai.Click += new System.EventHandler(this.btnNhapLai_Click);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToan.Location = new System.Drawing.Point(329, 322);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(140, 36);
            this.btnThanhToan.TabIndex = 6;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(486, 322);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(139, 36);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // grpThongKe
            // 
            this.grpThongKe.Controls.Add(this.lblTKKhach);
            this.grpThongKe.Controls.Add(this.lblTongKhach);
            this.grpThongKe.Controls.Add(this.lblTKTien);
            this.grpThongKe.Controls.Add(this.lblTongTien);
            this.grpThongKe.Location = new System.Drawing.Point(15, 370);
            this.grpThongKe.Name = "grpThongKe";
            this.grpThongKe.Size = new System.Drawing.Size(610, 75);
            this.grpThongKe.TabIndex = 8;
            this.grpThongKe.Text = "Thống kê";
            // 
            // lblTKKhach
            // 
            this.lblTKKhach.AutoSize = true;
            this.lblTKKhach.Location = new System.Drawing.Point(15, 33);
            this.lblTKKhach.Name = "lblTKKhach";
            this.lblTKKhach.Size = new System.Drawing.Size(105, 16);
            this.lblTKKhach.TabIndex = 0;
            this.lblTKKhach.Text = "Tổng số khách:";
            // 
            // lblTongKhach
            // 
            this.lblTongKhach.AutoSize = true;
            this.lblTongKhach.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongKhach.Location = new System.Drawing.Point(130, 33);
            this.lblTongKhach.Name = "lblTongKhach";
            this.lblTongKhach.ForeColor = System.Drawing.Color.Blue;
            this.lblTongKhach.Size = new System.Drawing.Size(16, 16);
            this.lblTongKhach.TabIndex = 1;
            this.lblTongKhach.Text = "0";
            // 
            // lblTKTien
            // 
            this.lblTKTien.AutoSize = true;
            this.lblTKTien.Location = new System.Drawing.Point(290, 33);
            this.lblTKTien.Name = "lblTKTien";
            this.lblTKTien.Size = new System.Drawing.Size(150, 16);
            this.lblTKTien.TabIndex = 2;
            this.lblTKTien.Text = "Tổng tiền thanh toán:";
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTien.Location = new System.Drawing.Point(450, 33);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.ForeColor = System.Drawing.Color.Red;
            this.lblTongTien.Size = new System.Drawing.Size(30, 16);
            this.lblTongTien.TabIndex = 3;
            this.lblTongTien.Text = "0 đ";
            // 
            // FrmCafe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 460);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpKhach);
            this.Controls.Add(this.grpNuocUong);
            this.Controls.Add(this.grpThucAn);
            this.Controls.Add(this.btnTinhTien);
            this.Controls.Add(this.btnNhapLai);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.grpThongKe);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmCafe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nâng cao - Quản lý thu tiền quán Cafe Sinh Viên";
            this.Load += new System.EventHandler(this.FrmCafe_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmCafe_FormClosing);
            this.grpKhach.ResumeLayout(false);
            this.grpKhach.PerformLayout();
            this.grpNuocUong.ResumeLayout(false);
            this.grpNuocUong.PerformLayout();
            this.grpThucAn.ResumeLayout(false);
            this.grpThucAn.PerformLayout();
            this.grpThongKe.ResumeLayout(false);
            this.grpThongKe.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpKhach;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.TextBox txtTenKH;
        private System.Windows.Forms.Label lblSoKhach;
        private System.Windows.Forms.TextBox txtSoKhach;
        private System.Windows.Forms.CheckBox chkSinhVien;
        private System.Windows.Forms.GroupBox grpNuocUong;
        private System.Windows.Forms.RadioButton rdoCafeDen;
        private System.Windows.Forms.RadioButton rdoCafeDa;
        private System.Windows.Forms.RadioButton rdoCafeSua;
        private System.Windows.Forms.RadioButton rdoCafeSuaDa;
        private System.Windows.Forms.RadioButton rdoCafeKem;
        private System.Windows.Forms.GroupBox grpThucAn;
        private System.Windows.Forms.RadioButton rdoBanhMyTrung;
        private System.Windows.Forms.RadioButton rdoBanhMyCa;
        private System.Windows.Forms.RadioButton rdoMyTomTrung;
        private System.Windows.Forms.RadioButton rdoMyXaoBo;
        private System.Windows.Forms.RadioButton rdoMyCay;
        private System.Windows.Forms.Button btnTinhTien;
        private System.Windows.Forms.Button btnNhapLai;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.GroupBox grpThongKe;
        private System.Windows.Forms.Label lblTKKhach;
        private System.Windows.Forms.Label lblTongKhach;
        private System.Windows.Forms.Label lblTKTien;
        private System.Windows.Forms.Label lblTongTien;
    }
}
