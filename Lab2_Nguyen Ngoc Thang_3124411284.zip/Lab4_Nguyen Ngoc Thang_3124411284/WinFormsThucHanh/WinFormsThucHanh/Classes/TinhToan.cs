﻿namespace WinFormsThucHanh
{
    /// <summary>
    /// Bài mẫu 1: lớp thực hiện các phép toán +, -, x, / của hai số.
    /// </summary>
    public class TinhToan
    {
        float _a, _b;

        public float a
        {
            get { return _a; }
            set { _a = value; }
        }

        public float b
        {
            get { return _b; }
            set { _b = value; }
        }

        public TinhToan() { a = b = 0; }

        public TinhToan(float a, float b)
        {
            _a = a;
            _b = b;
        }

        public float Cong() { return _a + _b; }
        public float Tru() { return _a - _b; }
        public float Nhan() { return _a * _b; }
        public float Chia() { return _a / _b; }

        /// <summary>Phép chia chỉ hợp lệ khi b khác 0.</summary>
        public bool ChiaDuoc() { return _b != 0; }
    }
}
