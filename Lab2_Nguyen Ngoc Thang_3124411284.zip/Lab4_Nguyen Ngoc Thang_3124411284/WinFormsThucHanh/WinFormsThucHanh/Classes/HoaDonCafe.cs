﻿namespace WinFormsThucHanh
{
    /// <summary>
    /// Bài nâng cao: hóa đơn của một nhóm khách ở quán Cafe Sinh Viên.
    /// Tiền = (giá nước + giá thức ăn) x số khách, giảm 20% nếu là sinh viên.
    /// </summary>
    public class HoaDonCafe
    {
        public static readonly string[] TenNuoc = { "Cafe đen", "Cafe đá", "Cafe sữa", "Cafe sữa đá", "Cafe kem" };
        public static readonly int[] GiaNuoc = { 20000, 25000, 25000, 30000, 35000 };
        public static readonly string[] TenThucAn = { "Bánh mỳ trứng", "Bánh mỳ cá", "Mỳ tôm trứng", "Mỳ xào bò", "Mỳ cay" };
        public static readonly int[] GiaThucAn = { 15000, 15000, 20000, 30000, 50000 };
        public const double TyLeGiamSinhVien = 0.2;

        public string TenKhach { get; set; }
        public int SoKhach { get; set; }
        public bool LaSinhVien { get; set; }
        public int LoaiNuoc { get; set; }    // chỉ số trong TenNuoc
        public int LoaiThucAn { get; set; }  // chỉ số trong TenThucAn

        public HoaDonCafe(string tenKhach, int soKhach, bool laSinhVien, int loaiNuoc, int loaiThucAn)
        {
            TenKhach = tenKhach;
            SoKhach = soKhach;
            LaSinhVien = laSinhVien;
            LoaiNuoc = loaiNuoc;
            LoaiThucAn = loaiThucAn;
        }

        public double TienChuaGiam()
        {
            return (double)(GiaNuoc[LoaiNuoc] + GiaThucAn[LoaiThucAn]) * SoKhach;
        }

        public double TienGiam()
        {
            return LaSinhVien ? TienChuaGiam() * TyLeGiamSinhVien : 0;
        }

        public double ThanhTien()
        {
            return TienChuaGiam() - TienGiam();
        }

        public string ChiTiet()
        {
            return "Khách hàng: " + TenKhach + (LaSinhVien ? " (Sinh viên)" : "") + "\n"
                 + "Số khách: " + SoKhach + "\n"
                 + "Nước uống: " + TenNuoc[LoaiNuoc] + " - " + GiaNuoc[LoaiNuoc].ToString("#,##0") + "đ\n"
                 + "Thức ăn: " + TenThucAn[LoaiThucAn] + " - " + GiaThucAn[LoaiThucAn].ToString("#,##0") + "đ\n"
                 + "Tạm tính: " + TienChuaGiam().ToString("#,##0") + "đ\n"
                 + "Giảm giá: " + TienGiam().ToString("#,##0") + "đ\n"
                 + "THÀNH TIỀN: " + ThanhTien().ToString("#,##0") + "đ";
        }
    }
}
