﻿using System;
using System.Collections.Generic;

namespace WinFormsThucHanh
{
    /// <summary>
    /// Bài tại lớp 2: lớp lưu trữ mảng một chiều số nguyên.
    /// Vị trí các phần tử tính từ 0.
    /// </summary>
    public class MangMotChieu
    {
        int[] _mang;

        public int SoPhanTu
        {
            get { return _mang.Length; }
        }

        public int this[int viTri]
        {
            get { return _mang[viTri]; }
        }

        public MangMotChieu() { _mang = new int[0]; }

        public MangMotChieu(int[] mang)
        {
            _mang = (int[])mang.Clone();
        }

        /// <summary>Tạo mảng từ chuỗi các số cách nhau bởi khoảng trắng, ví dụ "5 -2 8 1".</summary>
        public static MangMotChieu TuChuoi(string s)
        {
            string[] tach = s.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            int[] mang = new int[tach.Length];
            for (int i = 0; i < tach.Length; i++)
            {
                if (!int.TryParse(tach[i], out mang[i]))
                    throw new FormatException("Phần tử \"" + tach[i] + "\" không phải số nguyên.");
            }
            return new MangMotChieu(mang);
        }

        /// <summary>Tạo mảng n phần tử ngẫu nhiên trong đoạn [-50, 99].</summary>
        public static MangMotChieu NgauNhien(int n)
        {
            Random rd = new Random();
            int[] mang = new int[n];
            for (int i = 0; i < n; i++)
                mang[i] = rd.Next(-50, 100);
            return new MangMotChieu(mang);
        }

        public bool Rong() { return _mang.Length == 0; }

        public bool ViTriHopLe(int viTri) { return viTri >= 0 && viTri < _mang.Length; }

        // ----- Sắp xếp -----
        public void SapXepTang()
        {
            for (int i = 0; i < _mang.Length - 1; i++)
                for (int j = i + 1; j < _mang.Length; j++)
                    if (_mang[i] > _mang[j])
                        HoanVi(i, j);
        }

        public void SapXepGiam()
        {
            for (int i = 0; i < _mang.Length - 1; i++)
                for (int j = i + 1; j < _mang.Length; j++)
                    if (_mang[i] < _mang[j])
                        HoanVi(i, j);
        }

        private void HoanVi(int i, int j)
        {
            int t = _mang[i];
            _mang[i] = _mang[j];
            _mang[j] = t;
        }

        // ----- Tìm kiếm -----
        /// <summary>Trả về danh sách các vị trí có giá trị x (rỗng nếu không có).</summary>
        public List<int> TimViTri(int x)
        {
            List<int> ds = new List<int>();
            for (int i = 0; i < _mang.Length; i++)
                if (_mang[i] == x)
                    ds.Add(i);
            return ds;
        }

        public int LayGiaTri(int viTri)
        {
            if (!ViTriHopLe(viTri))
                throw new IndexOutOfRangeException("Vị trí phải từ 0 đến " + (_mang.Length - 1) + ".");
            return _mang[viTri];
        }

        // ----- Thêm -----
        /// <summary>Chèn x vào vị trí viTri (0..n, n = thêm vào cuối).</summary>
        public void Them(int viTri, int x)
        {
            if (viTri < 0 || viTri > _mang.Length)
                throw new IndexOutOfRangeException("Vị trí thêm phải từ 0 đến " + _mang.Length + ".");
            int[] moi = new int[_mang.Length + 1];
            for (int i = 0; i < viTri; i++)
                moi[i] = _mang[i];
            moi[viTri] = x;
            for (int i = viTri; i < _mang.Length; i++)
                moi[i + 1] = _mang[i];
            _mang = moi;
        }

        // ----- Tính tổng -----
        public long Tong()
        {
            long s = 0;
            foreach (int x in _mang) s += x;
            return s;
        }

        public long TongChan()
        {
            long s = 0;
            foreach (int x in _mang)
                if (x % 2 == 0) s += x;
            return s;
        }

        public long TongLe()
        {
            long s = 0;
            foreach (int x in _mang)
                if (x % 2 != 0) s += x;
            return s;
        }

        // ----- Lớn nhất / nhỏ nhất -----
        public int Max()
        {
            KiemTraRong();
            int max = _mang[0];
            foreach (int x in _mang)
                if (x > max) max = x;
            return max;
        }

        public int Min()
        {
            KiemTraRong();
            int min = _mang[0];
            foreach (int x in _mang)
                if (x < min) min = x;
            return min;
        }

        // ----- Thay thế -----
        /// <summary>Thay tất cả phần tử có giá trị cu bằng moi, trả về số phần tử đã thay.</summary>
        public int ThayTheGiaTri(int cu, int moi)
        {
            int dem = 0;
            for (int i = 0; i < _mang.Length; i++)
                if (_mang[i] == cu)
                {
                    _mang[i] = moi;
                    dem++;
                }
            return dem;
        }

        public void ThayTheViTri(int viTri, int moi)
        {
            if (!ViTriHopLe(viTri))
                throw new IndexOutOfRangeException("Vị trí phải từ 0 đến " + (_mang.Length - 1) + ".");
            _mang[viTri] = moi;
        }

        private void KiemTraRong()
        {
            if (Rong())
                throw new InvalidOperationException("Mảng đang rỗng.");
        }

        public override string ToString()
        {
            return string.Join("  ", _mang);
        }
    }
}
