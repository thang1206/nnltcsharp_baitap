﻿namespace WinFormsThucHanh
{
    /// <summary>
    /// Bài về nhà: hóa đơn trả phòng của Khách sạn Thanh Thanh.
    /// Tiền = giá phòng x số ngày + 10.000đ x số tiện nghi
    ///      + Karaoke 50.000đ + Ăn sáng 15.000đ x số ngày.
    /// </summary>
    public class HoaDonKhachSan
    {
        public static readonly int[] GiaPhong = { 300000, 350000, 400000 }; // đơn, đôi, ba
        public const int GiaTienNghi = 10000;
        public const int GiaKaraoke = 50000;
        public const int GiaAnSang = 15000;

        public string TenKhach { get; set; }
        public string DiaChi { get; set; }
        public int SoNgay { get; set; }
        public int LoaiPhong { get; set; }   // 0: đơn, 1: đôi, 2: ba
        public int SoTienNghi { get; set; }
        public bool Karaoke { get; set; }
        public bool AnSang { get; set; }

        public HoaDonKhachSan(string tenKhach, string diaChi, int soNgay, int loaiPhong,
                              int soTienNghi, bool karaoke, bool anSang)
        {
            TenKhach = tenKhach;
            DiaChi = diaChi;
            SoNgay = soNgay;
            LoaiPhong = loaiPhong;
            SoTienNghi = soTienNghi;
            Karaoke = karaoke;
            AnSang = anSang;
        }

        public long TienPhong() { return (long)GiaPhong[LoaiPhong] * SoNgay; }

        public long TienTienNghi() { return (long)SoTienNghi * GiaTienNghi; }

        public long TienDichVu()
        {
            long tien = 0;
            if (Karaoke) tien += GiaKaraoke;
            if (AnSang) tien += (long)GiaAnSang * SoNgay;
            return tien;
        }

        public long ThanhTien()
        {
            return TienPhong() + TienTienNghi() + TienDichVu();
        }
    }
}
