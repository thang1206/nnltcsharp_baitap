﻿using System;

namespace WinFormsThucHanh
{
    /// <summary>
    /// Bài tại lớp 1: giải phương trình bậc nhất ax + b = 0
    /// và phương trình bậc hai ax² + bx + c = 0.
    /// </summary>
    public class PhuongTrinhBacHai
    {
        double _a, _b, _c;

        public double A
        {
            get { return _a; }
            set { _a = value; }
        }

        public double B
        {
            get { return _b; }
            set { _b = value; }
        }

        public double C
        {
            get { return _c; }
            set { _c = value; }
        }

        public PhuongTrinhBacHai() { _a = _b = _c = 0; }

        // Dùng cho phương trình bậc nhất ax + b = 0
        public PhuongTrinhBacHai(double a, double b) : this(a, b, 0) { }

        public PhuongTrinhBacHai(double a, double b, double c)
        {
            _a = a;
            _b = b;
            _c = c;
        }

        public double Delta()
        {
            return _b * _b - 4 * _a * _c;
        }

        /// <summary>Giải ax + b = 0.</summary>
        public string GiaiBacNhat()
        {
            return GiaiBacNhat(_a, _b);
        }

        private static string GiaiBacNhat(double a, double b)
        {
            if (a == 0)
                return b == 0 ? "Phương trình vô số nghiệm" : "Phương trình vô nghiệm";
            return "Phương trình có nghiệm x = " + LamTron(-b / a);
        }

        /// <summary>Giải ax² + bx + c = 0 (a = 0 thì đưa về bx + c = 0).</summary>
        public string GiaiBacHai()
        {
            if (_a == 0)
                return "a = 0 => " + GiaiBacNhat(_b, _c);

            double delta = Delta();
            if (delta < 0)
                return "Phương trình vô nghiệm (Δ = " + LamTron(delta) + " < 0)";
            if (delta == 0)
                return "Phương trình có nghiệm kép x1 = x2 = " + LamTron(-_b / (2 * _a));

            double x1 = (-_b + Math.Sqrt(delta)) / (2 * _a);
            double x2 = (-_b - Math.Sqrt(delta)) / (2 * _a);
            return "Phương trình có 2 nghiệm: x1 = " + LamTron(x1) + "; x2 = " + LamTron(x2);
        }

        private static string LamTron(double x)
        {
            return Math.Round(x, 4).ToString();
        }
    }
}
