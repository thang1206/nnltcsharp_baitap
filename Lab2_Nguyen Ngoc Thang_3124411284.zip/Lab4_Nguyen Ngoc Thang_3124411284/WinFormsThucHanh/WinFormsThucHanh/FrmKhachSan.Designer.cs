﻿namespace WinFormsThucHanh
{
    partial class FrmKhachSan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpKhach = new System.Windows.Forms.GroupBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblSoNgay = new System.Windows.Forms.Label();
            this.txtSoNgay = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.grpLoaiPhong = new System.Windows.Forms.GroupBox();
            this.rdoPhongDon = new System.Windows.Forms.RadioButton();
            this.rdoPhongDoi = new System.Windows.Forms.RadioButton();
            this.rdoPhongBa = new System.Windows.Forms.RadioButton();
            this.grpTienNghi = new System.Windows.Forms.GroupBox();
            this.chkTivi = new System.Windows.Forms.CheckBox();
            this.chkTuLanh = new System.Windows.Forms.CheckBox();
            this.chkMayLanh = new System.Windows.Forms.CheckBox();
            this.chkBonTam = new System.Windows.Forms.CheckBox();
            this.grpDichVu = new System.Windows.Forms.GroupBox();
            this.chkKaraoke = new System.Windows.Forms.CheckBox();
            this.chkAnSang = new System.Windows.Forms.CheckBox();
            this.lblTT = new System.Windows.Forms.Label();
            this.lblThanhTien = new System.Windows.Forms.Label();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnNhapMoi = new System.Windows.Forms.Button();
            this.btnTongKet = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.grpThongKe = new System.Windows.Forms.GroupBox();
            this.lblTKKhach = new System.Windows.Forms.Label();
            this.lblTongKhach = new System.Windows.Forms.Label();
            this.lblTKTien = new System.Windows.Forms.Label();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.grpKhach.SuspendLayout();
            this.grpLoaiPhong.SuspendLayout();
            this.grpTienNghi.SuspendLayout();
            this.grpDichVu.SuspendLayout();
            this.grpThongKe.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(170, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Size = new System.Drawing.Size(0, 0);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "KHÁCH SẠN THANH THANH";
            // 
            // grpKhach
            // 
            this.grpKhach.Controls.Add(this.lblTen);
            this.grpKhach.Controls.Add(this.txtTen);
            this.grpKhach.Controls.Add(this.lblSoNgay);
            this.grpKhach.Controls.Add(this.txtSoNgay);
            this.grpKhach.Controls.Add(this.lblDiaChi);
            this.grpKhach.Controls.Add(this.txtDiaChi);
            this.grpKhach.Location = new System.Drawing.Point(15, 50);
            this.grpKhach.Name = "grpKhach";
            this.grpKhach.Size = new System.Drawing.Size(630, 100);
            this.grpKhach.TabIndex = 1;
            this.grpKhach.Text = "Thông tin khách";
            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(15, 31);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(75, 16);
            this.lblTen.TabIndex = 0;
            this.lblTen.Text = "Tên khách:";
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(110, 28);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(260, 22);
            this.txtTen.TabIndex = 1;
            this.txtTen.TextChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // lblSoNgay
            // 
            this.lblSoNgay.AutoSize = true;
            this.lblSoNgay.Location = new System.Drawing.Point(390, 31);
            this.lblSoNgay.Name = "lblSoNgay";
            this.lblSoNgay.Size = new System.Drawing.Size(75, 16);
            this.lblSoNgay.TabIndex = 2;
            this.lblSoNgay.Text = "Số ngày ở:";
            // 
            // txtSoNgay
            // 
            this.txtSoNgay.Location = new System.Drawing.Point(480, 28);
            this.txtSoNgay.Name = "txtSoNgay";
            this.txtSoNgay.Size = new System.Drawing.Size(80, 22);
            this.txtSoNgay.TabIndex = 3;
            this.txtSoNgay.TextChanged += new System.EventHandler(this.ThongTin_Changed);
            this.txtSoNgay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNgay_KeyPress);
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 66);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(55, 16);
            this.lblDiaChi.TabIndex = 4;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(110, 63);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(450, 22);
            this.txtDiaChi.TabIndex = 5;
            this.txtDiaChi.TextChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // grpLoaiPhong
            // 
            this.grpLoaiPhong.Controls.Add(this.rdoPhongDon);
            this.grpLoaiPhong.Controls.Add(this.rdoPhongDoi);
            this.grpLoaiPhong.Controls.Add(this.rdoPhongBa);
            this.grpLoaiPhong.Location = new System.Drawing.Point(15, 160);
            this.grpLoaiPhong.Name = "grpLoaiPhong";
            this.grpLoaiPhong.Size = new System.Drawing.Size(200, 135);
            this.grpLoaiPhong.TabIndex = 2;
            this.grpLoaiPhong.Text = "Loại phòng";
            // 
            // rdoPhongDon
            // 
            this.rdoPhongDon.AutoSize = true;
            this.rdoPhongDon.Location = new System.Drawing.Point(15, 28);
            this.rdoPhongDon.Name = "rdoPhongDon";
            this.rdoPhongDon.Size = new System.Drawing.Size(170, 20);
            this.rdoPhongDon.TabIndex = 0;
            this.rdoPhongDon.Text = "Phòng đơn (300.000đ)";
            this.rdoPhongDon.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoPhongDoi
            // 
            this.rdoPhongDoi.AutoSize = true;
            this.rdoPhongDoi.Location = new System.Drawing.Point(15, 61);
            this.rdoPhongDoi.Name = "rdoPhongDoi";
            this.rdoPhongDoi.Size = new System.Drawing.Size(170, 20);
            this.rdoPhongDoi.TabIndex = 1;
            this.rdoPhongDoi.Text = "Phòng đôi (350.000đ)";
            this.rdoPhongDoi.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // rdoPhongBa
            // 
            this.rdoPhongBa.AutoSize = true;
            this.rdoPhongBa.Location = new System.Drawing.Point(15, 94);
            this.rdoPhongBa.Name = "rdoPhongBa";
            this.rdoPhongBa.Size = new System.Drawing.Size(170, 20);
            this.rdoPhongBa.TabIndex = 2;
            this.rdoPhongBa.Text = "Phòng ba (400.000đ)";
            this.rdoPhongBa.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // grpTienNghi
            // 
            this.grpTienNghi.Controls.Add(this.chkTivi);
            this.grpTienNghi.Controls.Add(this.chkTuLanh);
            this.grpTienNghi.Controls.Add(this.chkMayLanh);
            this.grpTienNghi.Controls.Add(this.chkBonTam);
            this.grpTienNghi.Location = new System.Drawing.Point(225, 160);
            this.grpTienNghi.Name = "grpTienNghi";
            this.grpTienNghi.Size = new System.Drawing.Size(200, 135);
            this.grpTienNghi.TabIndex = 3;
            this.grpTienNghi.Text = "Tiện nghi (+10.000đ/loại)";
            // 
            // chkTivi
            // 
            this.chkTivi.AutoSize = true;
            this.chkTivi.Location = new System.Drawing.Point(15, 26);
            this.chkTivi.Name = "chkTivi";
            this.chkTivi.Size = new System.Drawing.Size(50, 20);
            this.chkTivi.TabIndex = 0;
            this.chkTivi.Text = "Tivi";
            this.chkTivi.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // chkTuLanh
            // 
            this.chkTuLanh.AutoSize = true;
            this.chkTuLanh.Location = new System.Drawing.Point(15, 51);
            this.chkTuLanh.Name = "chkTuLanh";
            this.chkTuLanh.Size = new System.Drawing.Size(75, 20);
            this.chkTuLanh.TabIndex = 1;
            this.chkTuLanh.Text = "Tủ lạnh";
            this.chkTuLanh.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // chkMayLanh
            // 
            this.chkMayLanh.AutoSize = true;
            this.chkMayLanh.Location = new System.Drawing.Point(15, 76);
            this.chkMayLanh.Name = "chkMayLanh";
            this.chkMayLanh.Size = new System.Drawing.Size(85, 20);
            this.chkMayLanh.TabIndex = 2;
            this.chkMayLanh.Text = "Máy lạnh";
            this.chkMayLanh.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // chkBonTam
            // 
            this.chkBonTam.AutoSize = true;
            this.chkBonTam.Location = new System.Drawing.Point(15, 101);
            this.chkBonTam.Name = "chkBonTam";
            this.chkBonTam.Size = new System.Drawing.Size(85, 20);
            this.chkBonTam.TabIndex = 3;
            this.chkBonTam.Text = "Bồn tắm";
            this.chkBonTam.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // grpDichVu
            // 
            this.grpDichVu.Controls.Add(this.chkKaraoke);
            this.grpDichVu.Controls.Add(this.chkAnSang);
            this.grpDichVu.Location = new System.Drawing.Point(435, 160);
            this.grpDichVu.Name = "grpDichVu";
            this.grpDichVu.Size = new System.Drawing.Size(210, 135);
            this.grpDichVu.TabIndex = 4;
            this.grpDichVu.Text = "Dịch vụ";
            // 
            // chkKaraoke
            // 
            this.chkKaraoke.AutoSize = true;
            this.chkKaraoke.Location = new System.Drawing.Point(15, 28);
            this.chkKaraoke.Name = "chkKaraoke";
            this.chkKaraoke.Size = new System.Drawing.Size(150, 20);
            this.chkKaraoke.TabIndex = 0;
            this.chkKaraoke.Text = "Karaoke (50.000đ)";
            this.chkKaraoke.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // chkAnSang
            // 
            this.chkAnSang.AutoSize = true;
            this.chkAnSang.Location = new System.Drawing.Point(15, 61);
            this.chkAnSang.Name = "chkAnSang";
            this.chkAnSang.Size = new System.Drawing.Size(185, 20);
            this.chkAnSang.TabIndex = 1;
            this.chkAnSang.Text = "Ăn sáng (15.000đ/ngày)";
            this.chkAnSang.CheckedChanged += new System.EventHandler(this.ThongTin_Changed);
            // 
            // lblTT
            // 
            this.lblTT.AutoSize = true;
            this.lblTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTT.Location = new System.Drawing.Point(15, 310);
            this.lblTT.Name = "lblTT";
            this.lblTT.Size = new System.Drawing.Size(90, 16);
            this.lblTT.TabIndex = 5;
            this.lblTT.Text = "Thành tiền:";
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.AutoSize = true;
            this.lblThanhTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThanhTien.Location = new System.Drawing.Point(120, 307);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.ForeColor = System.Drawing.Color.Red;
            this.lblThanhTien.Size = new System.Drawing.Size(40, 20);
            this.lblThanhTien.TabIndex = 6;
            this.lblThanhTien.Text = "0 đ";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToan.Location = new System.Drawing.Point(15, 340);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(145, 36);
            this.btnThanhToan.TabIndex = 7;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnNhapMoi
            // 
            this.btnNhapMoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapMoi.Location = new System.Drawing.Point(176, 340);
            this.btnNhapMoi.Name = "btnNhapMoi";
            this.btnNhapMoi.Size = new System.Drawing.Size(145, 36);
            this.btnNhapMoi.TabIndex = 8;
            this.btnNhapMoi.Text = "Nhập mới";
            this.btnNhapMoi.UseVisualStyleBackColor = true;
            this.btnNhapMoi.Click += new System.EventHandler(this.btnNhapMoi_Click);
            // 
            // btnTongKet
            // 
            this.btnTongKet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTongKet.Location = new System.Drawing.Point(337, 340);
            this.btnTongKet.Name = "btnTongKet";
            this.btnTongKet.Size = new System.Drawing.Size(145, 36);
            this.btnTongKet.TabIndex = 9;
            this.btnTongKet.Text = "Tổng kết";
            this.btnTongKet.UseVisualStyleBackColor = true;
            this.btnTongKet.Click += new System.EventHandler(this.btnTongKet_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(498, 340);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(147, 36);
            this.btnThoat.TabIndex = 10;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // grpThongKe
            // 
            this.grpThongKe.Controls.Add(this.lblTKKhach);
            this.grpThongKe.Controls.Add(this.lblTongKhach);
            this.grpThongKe.Controls.Add(this.lblTKTien);
            this.grpThongKe.Controls.Add(this.lblTongTien);
            this.grpThongKe.Location = new System.Drawing.Point(15, 388);
            this.grpThongKe.Name = "grpThongKe";
            this.grpThongKe.Size = new System.Drawing.Size(630, 75);
            this.grpThongKe.TabIndex = 11;
            this.grpThongKe.Text = "Thống kê trong ngày";
            // 
            // lblTKKhach
            // 
            this.lblTKKhach.AutoSize = true;
            this.lblTKKhach.Location = new System.Drawing.Point(15, 33);
            this.lblTKKhach.Name = "lblTKKhach";
            this.lblTKKhach.Size = new System.Drawing.Size(140, 16);
            this.lblTKKhach.TabIndex = 0;
            this.lblTKKhach.Text = "Tổng số lượt khách:";
            // 
            // lblTongKhach
            // 
            this.lblTongKhach.AutoSize = true;
            this.lblTongKhach.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongKhach.Location = new System.Drawing.Point(165, 33);
            this.lblTongKhach.Name = "lblTongKhach";
            this.lblTongKhach.ForeColor = System.Drawing.Color.Blue;
            this.lblTongKhach.Size = new System.Drawing.Size(16, 16);
            this.lblTongKhach.TabIndex = 1;
            this.lblTongKhach.Text = "0";
            // 
            // lblTKTien
            // 
            this.lblTKTien.AutoSize = true;
            this.lblTKTien.Location = new System.Drawing.Point(320, 33);
            this.lblTKTien.Name = "lblTKTien";
            this.lblTKTien.Size = new System.Drawing.Size(100, 16);
            this.lblTKTien.TabIndex = 2;
            this.lblTKTien.Text = "Tổng tiền thu:";
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTien.Location = new System.Drawing.Point(430, 33);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.ForeColor = System.Drawing.Color.Red;
            this.lblTongTien.Size = new System.Drawing.Size(30, 16);
            this.lblTongTien.TabIndex = 3;
            this.lblTongTien.Text = "0 đ";
            // 
            // FrmKhachSan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 478);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpKhach);
            this.Controls.Add(this.grpLoaiPhong);
            this.Controls.Add(this.grpTienNghi);
            this.Controls.Add(this.grpDichVu);
            this.Controls.Add(this.lblTT);
            this.Controls.Add(this.lblThanhTien);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnNhapMoi);
            this.Controls.Add(this.btnTongKet);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.grpThongKe);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmKhachSan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Về nhà - Thanh toán tiền phòng Khách sạn Thanh Thanh";
            this.Load += new System.EventHandler(this.FrmKhachSan_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmKhachSan_FormClosing);
            this.grpKhach.ResumeLayout(false);
            this.grpKhach.PerformLayout();
            this.grpLoaiPhong.ResumeLayout(false);
            this.grpLoaiPhong.PerformLayout();
            this.grpTienNghi.ResumeLayout(false);
            this.grpTienNghi.PerformLayout();
            this.grpDichVu.ResumeLayout(false);
            this.grpDichVu.PerformLayout();
            this.grpThongKe.ResumeLayout(false);
            this.grpThongKe.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpKhach;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblSoNgay;
        private System.Windows.Forms.TextBox txtSoNgay;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.GroupBox grpLoaiPhong;
        private System.Windows.Forms.RadioButton rdoPhongDon;
        private System.Windows.Forms.RadioButton rdoPhongDoi;
        private System.Windows.Forms.RadioButton rdoPhongBa;
        private System.Windows.Forms.GroupBox grpTienNghi;
        private System.Windows.Forms.CheckBox chkTivi;
        private System.Windows.Forms.CheckBox chkTuLanh;
        private System.Windows.Forms.CheckBox chkMayLanh;
        private System.Windows.Forms.CheckBox chkBonTam;
        private System.Windows.Forms.GroupBox grpDichVu;
        private System.Windows.Forms.CheckBox chkKaraoke;
        private System.Windows.Forms.CheckBox chkAnSang;
        private System.Windows.Forms.Label lblTT;
        private System.Windows.Forms.Label lblThanhTien;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnNhapMoi;
        private System.Windows.Forms.Button btnTongKet;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.GroupBox grpThongKe;
        private System.Windows.Forms.Label lblTKKhach;
        private System.Windows.Forms.Label lblTongKhach;
        private System.Windows.Forms.Label lblTKTien;
        private System.Windows.Forms.Label lblTongTien;
    }
}
