﻿namespace WinFormsThucHanh
{
    partial class FrmPhuongTrinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpLoai = new System.Windows.Forms.GroupBox();
            this.rdoBacNhat = new System.Windows.Forms.RadioButton();
            this.rdoBacHai = new System.Windows.Forms.RadioButton();
            this.lblA = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.lblB = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.lblC = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.btnGiai = new System.Windows.Forms.Button();
            this.btnNhapLai = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.lblKetQua = new System.Windows.Forms.Label();
            this.txtKetQua = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.grpLoai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(115, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Size = new System.Drawing.Size(0, 0);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "GIẢI PHƯƠNG TRÌNH";
            // 
            // grpLoai
            // 
            this.grpLoai.Controls.Add(this.rdoBacNhat);
            this.grpLoai.Controls.Add(this.rdoBacHai);
            this.grpLoai.Location = new System.Drawing.Point(30, 55);
            this.grpLoai.Name = "grpLoai";
            this.grpLoai.Size = new System.Drawing.Size(400, 62);
            this.grpLoai.TabIndex = 1;
            this.grpLoai.Text = "Chọn loại phương trình";
            // 
            // rdoBacNhat
            // 
            this.rdoBacNhat.AutoSize = true;
            this.rdoBacNhat.Location = new System.Drawing.Point(15, 27);
            this.rdoBacNhat.Name = "rdoBacNhat";
            this.rdoBacNhat.Size = new System.Drawing.Size(160, 20);
            this.rdoBacNhat.TabIndex = 0;
            this.rdoBacNhat.Text = "Bậc nhất (ax + b = 0)";
            this.rdoBacNhat.CheckedChanged += new System.EventHandler(this.rdoLoai_CheckedChanged);
            // 
            // rdoBacHai
            // 
            this.rdoBacHai.AutoSize = true;
            this.rdoBacHai.Location = new System.Drawing.Point(190, 27);
            this.rdoBacHai.Name = "rdoBacHai";
            this.rdoBacHai.Size = new System.Drawing.Size(200, 20);
            this.rdoBacHai.TabIndex = 1;
            this.rdoBacHai.Text = "Bậc hai (ax² + bx + c = 0)";
            this.rdoBacHai.CheckedChanged += new System.EventHandler(this.rdoLoai_CheckedChanged);
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(30, 137);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(55, 16);
            this.lblA.TabIndex = 2;
            this.lblA.Text = "Nhập a:";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(110, 134);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(170, 22);
            this.txtA.TabIndex = 3;
            this.txtA.TextChanged += new System.EventHandler(this.txtHeSo_TextChanged);
            this.txtA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHeSo_KeyPress);
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(30, 172);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(55, 16);
            this.lblB.TabIndex = 4;
            this.lblB.Text = "Nhập b:";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(110, 169);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(170, 22);
            this.txtB.TabIndex = 5;
            this.txtB.TextChanged += new System.EventHandler(this.txtHeSo_TextChanged);
            this.txtB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHeSo_KeyPress);
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(30, 207);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(55, 16);
            this.lblC.TabIndex = 6;
            this.lblC.Text = "Nhập c:";
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(110, 204);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(170, 22);
            this.txtC.TabIndex = 7;
            this.txtC.TextChanged += new System.EventHandler(this.txtHeSo_TextChanged);
            this.txtC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHeSo_KeyPress);
            // 
            // btnGiai
            // 
            this.btnGiai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGiai.Location = new System.Drawing.Point(310, 131);
            this.btnGiai.Name = "btnGiai";
            this.btnGiai.Size = new System.Drawing.Size(120, 32);
            this.btnGiai.TabIndex = 8;
            this.btnGiai.Text = "Giải";
            this.btnGiai.UseVisualStyleBackColor = true;
            this.btnGiai.Click += new System.EventHandler(this.btnGiai_Click);
            // 
            // btnNhapLai
            // 
            this.btnNhapLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapLai.Location = new System.Drawing.Point(310, 168);
            this.btnNhapLai.Name = "btnNhapLai";
            this.btnNhapLai.Size = new System.Drawing.Size(120, 32);
            this.btnNhapLai.TabIndex = 9;
            this.btnNhapLai.Text = "Nhập lại";
            this.btnNhapLai.UseVisualStyleBackColor = true;
            this.btnNhapLai.Click += new System.EventHandler(this.btnNhapLai_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(310, 205);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(120, 32);
            this.btnThoat.TabIndex = 10;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // lblKetQua
            // 
            this.lblKetQua.AutoSize = true;
            this.lblKetQua.Location = new System.Drawing.Point(30, 250);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(65, 16);
            this.lblKetQua.TabIndex = 11;
            this.lblKetQua.Text = "Kết quả:";
            // 
            // txtKetQua
            // 
            this.txtKetQua.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKetQua.Location = new System.Drawing.Point(110, 247);
            this.txtKetQua.Name = "txtKetQua";
            this.txtKetQua.Multiline = true;
            this.txtKetQua.ReadOnly = true;
            this.txtKetQua.TabStop = false;
            this.txtKetQua.ForeColor = System.Drawing.Color.Blue;
            this.txtKetQua.Size = new System.Drawing.Size(320, 48);
            this.txtKetQua.TabIndex = 12;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FrmPhuongTrinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 315);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpLoai);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.btnGiai);
            this.Controls.Add(this.btnNhapLai);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.lblKetQua);
            this.Controls.Add(this.txtKetQua);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmPhuongTrinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài tại lớp 1 - Giải phương trình";
            this.Load += new System.EventHandler(this.FrmPhuongTrinh_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmPhuongTrinh_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.grpLoai.ResumeLayout(false);
            this.grpLoai.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpLoai;
        private System.Windows.Forms.RadioButton rdoBacNhat;
        private System.Windows.Forms.RadioButton rdoBacHai;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Button btnGiai;
        private System.Windows.Forms.Button btnNhapLai;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label lblKetQua;
        private System.Windows.Forms.TextBox txtKetQua;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
