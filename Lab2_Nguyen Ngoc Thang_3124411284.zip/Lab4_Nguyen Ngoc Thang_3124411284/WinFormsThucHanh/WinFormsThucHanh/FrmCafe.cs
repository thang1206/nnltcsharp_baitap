﻿using System;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmCafe : Form
    {
        RadioButton[] rdoNuoc;
        RadioButton[] rdoThucAn;

        HoaDonCafe hoaDon;      // hóa đơn của nhóm khách hiện tại (sau khi bấm Tính tiền)
        int tongSoKhach = 0;
        double tongTien = 0;

        public FrmCafe()
        {
            InitializeComponent();
            rdoNuoc = new[] { rdoCafeDen, rdoCafeDa, rdoCafeSua, rdoCafeSuaDa, rdoCafeKem };
            rdoThucAn = new[] { rdoBanhMyTrung, rdoBanhMyCa, rdoMyTomTrung, rdoMyXaoBo, rdoMyCay };
        }

        private void FrmCafe_Load(object sender, EventArgs e)
        {
            TrangThaiBanDau();
        }

        private static int ViTriDuocChon(RadioButton[] ds)
        {
            for (int i = 0; i < ds.Length; i++)
                if (ds[i].Checked)
                    return i;
            return -1;
        }

        // Quay về trạng thái ban đầu: xóa dữ liệu, 3 nút mờ, con trỏ ở ô tên khách hàng
        private void TrangThaiBanDau()
        {
            txtTenKH.Clear();
            txtSoKhach.Clear();
            chkSinhVien.Checked = false;
            foreach (RadioButton r in rdoNuoc) r.Checked = false;
            foreach (RadioButton r in rdoThucAn) r.Checked = false;
            hoaDon = null;
            btnTinhTien.Enabled = false;
            btnNhapLai.Enabled = false;
            btnThanhToan.Enabled = false;
            this.ActiveControl = txtTenKH;
            txtTenKH.Focus();
        }

        private bool DuThongTin()
        {
            int soKhach;
            return txtTenKH.Text.Trim() != ""
                && int.TryParse(txtSoKhach.Text, out soKhach) && soKhach > 0
                && ViTriDuocChon(rdoNuoc) >= 0
                && ViTriDuocChon(rdoThucAn) >= 0;
        }

        // Mỗi khi thông tin thay đổi: nhập đủ thì btnTinhTien sáng,
        // hóa đơn đã tính trước đó không còn đúng nên phải tính lại
        private void ThongTin_Changed(object sender, EventArgs e)
        {
            btnTinhTien.Enabled = DuThongTin();
            if (hoaDon != null)
            {
                hoaDon = null;
                btnThanhToan.Enabled = false;
            }
        }

        // Số khách hàng chỉ cho nhập số
        private void txtSoKhach_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void btnTinhTien_Click(object sender, EventArgs e)
        {
            if (txtTenKH.Text.Trim() == "")
            {
                MessageBox.Show("Tên khách hàng không được để trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenKH.Focus();
                return;
            }
            int soKhach;
            if (!int.TryParse(txtSoKhach.Text, out soKhach) || soKhach <= 0)
            {
                MessageBox.Show("Số khách phải là số nguyên lớn hơn 0!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSoKhach.Focus();
                return;
            }

            hoaDon = new HoaDonCafe(txtTenKH.Text.Trim(), soKhach, chkSinhVien.Checked,
                                    ViTriDuocChon(rdoNuoc), ViTriDuocChon(rdoThucAn));
            MessageBox.Show(hoaDon.ChiTiet(), "Hóa đơn", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btnNhapLai.Enabled = true;
            btnThanhToan.Enabled = true;
        }

        private void btnNhapLai_Click(object sender, EventArgs e)
        {
            TrangThaiBanDau();   // btnNhapLai cũng mờ đi trong hàm này
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (hoaDon == null)
                return;
            tongSoKhach += hoaDon.SoKhach;
            tongTien += hoaDon.ThanhTien();
            lblTongKhach.Text = tongSoKhach.ToString();
            lblTongTien.Text = tongTien.ToString("#,##0") + " đ";
            TrangThaiBanDau();   // sẵn sàng cho nhóm khách mới, btnThanhToan mờ
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmCafe_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi chương trình?", "Thoát",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
