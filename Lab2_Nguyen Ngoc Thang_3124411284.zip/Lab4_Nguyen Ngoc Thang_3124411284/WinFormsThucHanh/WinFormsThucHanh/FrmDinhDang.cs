﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmDinhDang : Form
    {
        public FrmDinhDang()
        {
            InitializeComponent();
        }

        // Ba checkbox dùng chung một sự kiện: ghép các FontStyle đang được chọn
        private void chkFontStyle_CheckedChanged(object sender, EventArgs e)
        {
            FontStyle kieu = FontStyle.Regular;
            if (chkBold.Checked)
                kieu = kieu | FontStyle.Bold;
            if (chkItalic.Checked)
                kieu = kieu | FontStyle.Italic;
            if (chkUnderline.Checked)
                kieu = kieu | FontStyle.Underline;
            lblNoiDung.Font = new Font(lblNoiDung.Font, kieu);
        }

        private void rdo_red_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked == true)
                lblNoiDung.ForeColor = Color.Red;
        }

        private void rdo_green_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoGreen.Checked == true)
                lblNoiDung.ForeColor = Color.Green;
        }

        private void rdo_blue_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBlue.Checked == true)
                lblNoiDung.ForeColor = Color.Blue;
        }

        private void rdo_black_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBlack.Checked == true)
                lblNoiDung.ForeColor = Color.Black;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmDinhDang_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có chắc chắn muốn thoát?", "Exit",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
