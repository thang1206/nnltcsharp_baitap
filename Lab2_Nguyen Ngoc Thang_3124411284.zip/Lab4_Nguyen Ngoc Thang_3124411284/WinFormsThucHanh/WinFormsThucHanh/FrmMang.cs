﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmMang : Form
    {
        MangMotChieu mang = new MangMotChieu();

        public FrmMang()
        {
            InitializeComponent();
        }

        // ----- Hàm tiện ích -----
        private void HienMang()
        {
            txtMang.Text = mang.Rong() ? "(mảng rỗng)" : mang.ToString();
        }

        private void BaoLoi(string thongBao)
        {
            MessageBox.Show(thongBao, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool KiemTraMang()
        {
            if (mang.Rong())
            {
                BaoLoi("Mảng đang rỗng, hãy nhập mảng trước!");
                txtNhapMang.Focus();
                return false;
            }
            return true;
        }

        private bool DocSoNguyen(TextBox txt, string ten, out int x)
        {
            if (!int.TryParse(txt.Text.Trim(), out x))
            {
                BaoLoi(ten + " phải là số nguyên!");
                txt.Focus();
                txt.SelectAll();
                return false;
            }
            return true;
        }

        // Chỉ cho nhập số nguyên (cho phép dấu '-' ở đầu)
        private void txtSoNguyen_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar))
                return;
            if (e.KeyChar == '-' && txt.SelectionStart == 0 && !txt.Text.Contains("-"))
                return;
            e.Handled = true;
        }

        // Ô nhập mảng: chỉ cho số, dấu '-' và khoảng trắng
        private void txtNhapMang_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ' ')
                e.Handled = true;
        }

        // ----- Nhập mảng -----
        private void btnTaoMang_Click(object sender, EventArgs e)
        {
            if (txtNhapMang.Text.Trim() == "")
            {
                BaoLoi("Hãy nhập các phần tử của mảng!");
                txtNhapMang.Focus();
                return;
            }
            try
            {
                mang = MangMotChieu.TuChuoi(txtNhapMang.Text);
                HienMang();
                txtKetQua.Text = "Đã tạo mảng " + mang.SoPhanTu + " phần tử.";
            }
            catch (Exception ex)
            {
                BaoLoi(ex.Message);
            }
        }

        private void btnNgauNhien_Click(object sender, EventArgs e)
        {
            int n;
            if (!DocSoNguyen(txtN, "Số phần tử n", out n))
                return;
            if (n <= 0 || n > 100)
            {
                BaoLoi("Số phần tử n phải từ 1 đến 100!");
                return;
            }
            mang = MangMotChieu.NgauNhien(n);
            txtNhapMang.Text = mang.ToString();
            HienMang();
            txtKetQua.Text = "Đã tạo mảng ngẫu nhiên " + n + " phần tử.";
        }

        // ----- Sắp xếp -----
        private void btnTang_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            mang.SapXepTang();
            HienMang();
            txtKetQua.Text = "Đã sắp xếp mảng tăng dần.";
        }

        private void btnGiam_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            mang.SapXepGiam();
            HienMang();
            txtKetQua.Text = "Đã sắp xếp mảng giảm dần.";
        }

        // ----- Tính toán -----
        private void btnTong_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            txtKetQua.Text = "Tổng mảng = " + mang.Tong();
        }

        private void btnTongChan_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            txtKetQua.Text = "Tổng các phần tử chẵn = " + mang.TongChan();
        }

        private void btnTongLe_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            txtKetQua.Text = "Tổng các phần tử lẻ = " + mang.TongLe();
        }

        private void btnMax_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            int max = mang.Max();
            txtKetQua.Text = "Giá trị lớn nhất = " + max + " tại vị trí " + string.Join(", ", mang.TimViTri(max));
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            if (!KiemTraMang()) return;
            int min = mang.Min();
            txtKetQua.Text = "Giá trị nhỏ nhất = " + min + " tại vị trí " + string.Join(", ", mang.TimViTri(min));
        }

        // ----- Tìm kiếm -----
        private void btnTimGiaTri_Click(object sender, EventArgs e)
        {
            int x;
            if (!KiemTraMang() || !DocSoNguyen(txtGiaTriTim, "Giá trị cần tìm", out x))
                return;
            List<int> viTri = mang.TimViTri(x);
            if (viTri.Count == 0)
                txtKetQua.Text = "Không tìm thấy " + x + " trong mảng.";
            else
                txtKetQua.Text = "Tìm thấy " + x + " tại vị trí: " + string.Join(", ", viTri);
        }

        private void btnTimViTri_Click(object sender, EventArgs e)
        {
            int vt;
            if (!KiemTraMang() || !DocSoNguyen(txtViTriTim, "Vị trí", out vt))
                return;
            if (!mang.ViTriHopLe(vt))
            {
                BaoLoi("Vị trí phải từ 0 đến " + (mang.SoPhanTu - 1) + "!");
                return;
            }
            txtKetQua.Text = "Phần tử tại vị trí " + vt + " là " + mang.LayGiaTri(vt);
        }

        // ----- Thêm -----
        private void btnThem_Click(object sender, EventArgs e)
        {
            int vt, x;
            if (!DocSoNguyen(txtViTriThem, "Vị trí thêm", out vt) || !DocSoNguyen(txtGiaTriThem, "Giá trị thêm", out x))
                return;
            if (vt < 0 || vt > mang.SoPhanTu)
            {
                BaoLoi("Vị trí thêm phải từ 0 đến " + mang.SoPhanTu + "!");
                return;
            }
            mang.Them(vt, x);
            HienMang();
            txtKetQua.Text = "Đã thêm " + x + " vào vị trí " + vt + ".";
        }

        // ----- Thay thế -----
        private void btnThayGiaTri_Click(object sender, EventArgs e)
        {
            int cu, moi;
            if (!KiemTraMang() || !DocSoNguyen(txtGiaTriCu, "Giá trị cũ", out cu) || !DocSoNguyen(txtGiaTriMoi, "Giá trị mới", out moi))
                return;
            int dem = mang.ThayTheGiaTri(cu, moi);
            if (dem == 0)
            {
                txtKetQua.Text = "Không có phần tử nào bằng " + cu + ".";
                return;
            }
            HienMang();
            txtKetQua.Text = "Đã thay " + dem + " phần tử " + cu + " thành " + moi + ".";
        }

        private void btnThayViTri_Click(object sender, EventArgs e)
        {
            int vt, moi;
            if (!KiemTraMang() || !DocSoNguyen(txtViTriThay, "Vị trí", out vt) || !DocSoNguyen(txtGiaTriMoi2, "Giá trị mới", out moi))
                return;
            if (!mang.ViTriHopLe(vt))
            {
                BaoLoi("Vị trí phải từ 0 đến " + (mang.SoPhanTu - 1) + "!");
                return;
            }
            int cu = mang[vt];
            mang.ThayTheViTri(vt, moi);
            HienMang();
            txtKetQua.Text = "Vị trí " + vt + ": " + cu + " => " + moi;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmMang_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn đóng form không?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
