﻿using System;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void MoForm(Form f)
        {
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btnBaiMau1_Click(object sender, EventArgs e) { MoForm(new FrmTinhToan()); }

        private void btnBaiMau2_Click(object sender, EventArgs e) { MoForm(new FrmDinhDang()); }

        private void btnPhuongTrinh_Click(object sender, EventArgs e) { MoForm(new FrmPhuongTrinh()); }

        private void btnMang_Click(object sender, EventArgs e) { MoForm(new FrmMang()); }

        private void btnCafe_Click(object sender, EventArgs e) { MoForm(new FrmCafe()); }

        private void btnKhachSan_Click(object sender, EventArgs e) { MoForm(new FrmKhachSan()); }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
