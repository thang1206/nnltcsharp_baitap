﻿namespace WinFormsThucHanh
{
    partial class FrmTinhToan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lbl_a = new System.Windows.Forms.Label();
            this.txt_a = new System.Windows.Forms.TextBox();
            this.lbl_b = new System.Windows.Forms.Label();
            this.txt_b = new System.Windows.Forms.TextBox();
            this.grpPhepToan = new System.Windows.Forms.GroupBox();
            this.rdo_cong = new System.Windows.Forms.RadioButton();
            this.rdo_tru = new System.Windows.Forms.RadioButton();
            this.rdo_nhan = new System.Windows.Forms.RadioButton();
            this.rdo_chia = new System.Windows.Forms.RadioButton();
            this.lbl_KetQua = new System.Windows.Forms.Label();
            this.txt_KetQua = new System.Windows.Forms.TextBox();
            this.btn_Tinh = new System.Windows.Forms.Button();
            this.btn_Thoat = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.grpPhepToan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(105, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Size = new System.Drawing.Size(0, 0);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "TÍNH TOÁN HAI SỐ";
            // 
            // lbl_a
            // 
            this.lbl_a.AutoSize = true;
            this.lbl_a.Location = new System.Drawing.Point(30, 65);
            this.lbl_a.Name = "lbl_a";
            this.lbl_a.Size = new System.Drawing.Size(55, 16);
            this.lbl_a.TabIndex = 1;
            this.lbl_a.Text = "Nhập a:";
            // 
            // txt_a
            // 
            this.txt_a.Location = new System.Drawing.Point(130, 62);
            this.txt_a.Name = "txt_a";
            this.txt_a.Size = new System.Drawing.Size(260, 22);
            this.txt_a.TabIndex = 2;
            this.txt_a.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSo_KeyPress);
            this.txt_a.Validating += new System.ComponentModel.CancelEventHandler(this.txtSo_Validating);
            this.txt_a.TextChanged += new System.EventHandler(this.txtSo_TextChanged);
            // 
            // lbl_b
            // 
            this.lbl_b.AutoSize = true;
            this.lbl_b.Location = new System.Drawing.Point(30, 100);
            this.lbl_b.Name = "lbl_b";
            this.lbl_b.Size = new System.Drawing.Size(55, 16);
            this.lbl_b.TabIndex = 3;
            this.lbl_b.Text = "Nhập b:";
            // 
            // txt_b
            // 
            this.txt_b.Location = new System.Drawing.Point(130, 97);
            this.txt_b.Name = "txt_b";
            this.txt_b.Size = new System.Drawing.Size(260, 22);
            this.txt_b.TabIndex = 4;
            this.txt_b.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSo_KeyPress);
            this.txt_b.Validating += new System.ComponentModel.CancelEventHandler(this.txtSo_Validating);
            this.txt_b.TextChanged += new System.EventHandler(this.txtSo_TextChanged);
            // 
            // grpPhepToan
            // 
            this.grpPhepToan.Controls.Add(this.rdo_cong);
            this.grpPhepToan.Controls.Add(this.rdo_tru);
            this.grpPhepToan.Controls.Add(this.rdo_nhan);
            this.grpPhepToan.Controls.Add(this.rdo_chia);
            this.grpPhepToan.Location = new System.Drawing.Point(30, 132);
            this.grpPhepToan.Name = "grpPhepToan";
            this.grpPhepToan.Size = new System.Drawing.Size(360, 62);
            this.grpPhepToan.TabIndex = 5;
            this.grpPhepToan.Text = "Phép toán";
            // 
            // rdo_cong
            // 
            this.rdo_cong.AutoSize = true;
            this.rdo_cong.Location = new System.Drawing.Point(20, 27);
            this.rdo_cong.Name = "rdo_cong";
            this.rdo_cong.Size = new System.Drawing.Size(60, 20);
            this.rdo_cong.TabIndex = 0;
            this.rdo_cong.Text = "Cộng";
            this.rdo_cong.CheckedChanged += new System.EventHandler(this.rdoPhepToan_CheckedChanged);
            // 
            // rdo_tru
            // 
            this.rdo_tru.AutoSize = true;
            this.rdo_tru.Location = new System.Drawing.Point(105, 27);
            this.rdo_tru.Name = "rdo_tru";
            this.rdo_tru.Size = new System.Drawing.Size(50, 20);
            this.rdo_tru.TabIndex = 1;
            this.rdo_tru.Text = "Trừ";
            this.rdo_tru.CheckedChanged += new System.EventHandler(this.rdoPhepToan_CheckedChanged);
            // 
            // rdo_nhan
            // 
            this.rdo_nhan.AutoSize = true;
            this.rdo_nhan.Location = new System.Drawing.Point(185, 27);
            this.rdo_nhan.Name = "rdo_nhan";
            this.rdo_nhan.Size = new System.Drawing.Size(60, 20);
            this.rdo_nhan.TabIndex = 2;
            this.rdo_nhan.Text = "Nhân";
            this.rdo_nhan.CheckedChanged += new System.EventHandler(this.rdoPhepToan_CheckedChanged);
            // 
            // rdo_chia
            // 
            this.rdo_chia.AutoSize = true;
            this.rdo_chia.Location = new System.Drawing.Point(270, 27);
            this.rdo_chia.Name = "rdo_chia";
            this.rdo_chia.Size = new System.Drawing.Size(55, 20);
            this.rdo_chia.TabIndex = 3;
            this.rdo_chia.Text = "Chia";
            this.rdo_chia.CheckedChanged += new System.EventHandler(this.rdoPhepToan_CheckedChanged);
            // 
            // lbl_KetQua
            // 
            this.lbl_KetQua.AutoSize = true;
            this.lbl_KetQua.Location = new System.Drawing.Point(30, 215);
            this.lbl_KetQua.Name = "lbl_KetQua";
            this.lbl_KetQua.Size = new System.Drawing.Size(65, 16);
            this.lbl_KetQua.TabIndex = 6;
            this.lbl_KetQua.Text = "Kết quả:";
            // 
            // txt_KetQua
            // 
            this.txt_KetQua.Location = new System.Drawing.Point(130, 212);
            this.txt_KetQua.Name = "txt_KetQua";
            this.txt_KetQua.ReadOnly = true;
            this.txt_KetQua.TabStop = false;
            this.txt_KetQua.Size = new System.Drawing.Size(260, 22);
            this.txt_KetQua.TabIndex = 7;
            // 
            // btn_Tinh
            // 
            this.btn_Tinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Tinh.Location = new System.Drawing.Point(130, 252);
            this.btn_Tinh.Name = "btn_Tinh";
            this.btn_Tinh.Size = new System.Drawing.Size(120, 32);
            this.btn_Tinh.TabIndex = 8;
            this.btn_Tinh.Text = "Tính";
            this.btn_Tinh.UseVisualStyleBackColor = true;
            this.btn_Tinh.Click += new System.EventHandler(this.btn_Tinh_Click);
            // 
            // btn_Thoat
            // 
            this.btn_Thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Thoat.Location = new System.Drawing.Point(270, 252);
            this.btn_Thoat.Name = "btn_Thoat";
            this.btn_Thoat.Size = new System.Drawing.Size(120, 32);
            this.btn_Thoat.TabIndex = 9;
            this.btn_Thoat.Text = "Thoát";
            this.btn_Thoat.UseVisualStyleBackColor = true;
            this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FrmTinhToan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 305);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lbl_a);
            this.Controls.Add(this.txt_a);
            this.Controls.Add(this.lbl_b);
            this.Controls.Add(this.txt_b);
            this.Controls.Add(this.grpPhepToan);
            this.Controls.Add(this.lbl_KetQua);
            this.Controls.Add(this.txt_KetQua);
            this.Controls.Add(this.btn_Tinh);
            this.Controls.Add(this.btn_Thoat);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmTinhToan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài mẫu 1 - Tính toán";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmTinhToan_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.grpPhepToan.ResumeLayout(false);
            this.grpPhepToan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lbl_a;
        private System.Windows.Forms.TextBox txt_a;
        private System.Windows.Forms.Label lbl_b;
        private System.Windows.Forms.TextBox txt_b;
        private System.Windows.Forms.GroupBox grpPhepToan;
        private System.Windows.Forms.RadioButton rdo_cong;
        private System.Windows.Forms.RadioButton rdo_tru;
        private System.Windows.Forms.RadioButton rdo_nhan;
        private System.Windows.Forms.RadioButton rdo_chia;
        private System.Windows.Forms.Label lbl_KetQua;
        private System.Windows.Forms.TextBox txt_KetQua;
        private System.Windows.Forms.Button btn_Tinh;
        private System.Windows.Forms.Button btn_Thoat;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
