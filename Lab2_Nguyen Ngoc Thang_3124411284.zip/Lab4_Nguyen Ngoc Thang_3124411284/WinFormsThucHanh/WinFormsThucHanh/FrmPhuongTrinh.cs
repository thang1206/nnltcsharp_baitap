﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmPhuongTrinh : Form
    {
        public FrmPhuongTrinh()
        {
            InitializeComponent();
        }

        private void FrmPhuongTrinh_Load(object sender, EventArgs e)
        {
            rdoBacNhat.Checked = true;
            btnGiai.Enabled = false;   // Form load: nút Giải mờ đi
            this.ActiveControl = txtA;
        }

        private static bool DocSo(string s, out double x)
        {
            return double.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Float,
                                   CultureInfo.InvariantCulture, out x);
        }

        // Bậc nhất: TextBox c bị mờ; Bậc hai: hiện đủ 3 TextBox
        private void rdoLoai_CheckedChanged(object sender, EventArgs e)
        {
            bool bacHai = rdoBacHai.Checked;
            txtC.Enabled = bacHai;
            lblC.Enabled = bacHai;
            if (!bacHai)
            {
                txtC.Text = "";
                errorProvider1.SetError(txtC, "");
            }
            txtKetQua.Text = "";
            CapNhatNutGiai();
        }

        // Nút Giải chỉ sáng khi đã nhập đủ các hệ số cần thiết
        private void CapNhatNutGiai()
        {
            bool du = txtA.Text.Trim() != "" && txtB.Text.Trim() != "";
            if (rdoBacHai.Checked)
                du = du && txtC.Text.Trim() != "";
            btnGiai.Enabled = du;
        }

        private void txtHeSo_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.SetError((Control)sender, "");
            txtKetQua.Text = "";
            CapNhatNutGiai();
        }

        private void txtHeSo_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar))
                return;
            if ((e.KeyChar == '.' || e.KeyChar == ',') && txt.Text.IndexOfAny(new[] { '.', ',' }) < 0)
                return;
            if (e.KeyChar == '-' && txt.SelectionStart == 0 && !txt.Text.Contains("-"))
                return;
            e.Handled = true;
        }

        private bool KiemTra(TextBox txt, string ten, out double x)
        {
            if (!DocSo(txt.Text, out x))
            {
                errorProvider1.SetError(txt, "Hệ số " + ten + " phải là số!");
                return false;
            }
            errorProvider1.SetError(txt, "");
            return true;
        }

        private void btnGiai_Click(object sender, EventArgs e)
        {
            double a, b, c = 0;
            bool ok = KiemTra(txtA, "a", out a);
            ok = KiemTra(txtB, "b", out b) && ok;
            if (rdoBacHai.Checked)
                ok = KiemTra(txtC, "c", out c) && ok;
            if (!ok)
            {
                MessageBox.Show("Dữ liệu nhập vào không hợp lệ, vui lòng kiểm tra lại!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            PhuongTrinhBacHai pt = new PhuongTrinhBacHai(a, b, c);
            txtKetQua.Text = rdoBacNhat.Checked ? pt.GiaiBacNhat() : pt.GiaiBacHai();
            btnGiai.Enabled = false;   // Giải xong thì nút Giải mờ đi
        }

        private void btnNhapLai_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtKetQua.Clear();
            errorProvider1.Clear();
            btnGiai.Enabled = false;
            txtA.Focus();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmPhuongTrinh_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn đóng form không?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
