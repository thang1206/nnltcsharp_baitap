﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Forms;

namespace WinFormsThucHanh
{
    public partial class FrmTinhToan : Form
    {
        public FrmTinhToan()
        {
            InitializeComponent();
        }

        // Đọc số thực, chấp nhận cả dấu '.' và ',' làm dấu thập phân
        private static bool DocSo(string s, out float x)
        {
            return float.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Float,
                                  CultureInfo.InvariantCulture, out x);
        }

        // Mức 2: chặn không cho nhập ký tự khác số
        private void txtSo_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar))
                return;
            // Cho phép một dấu thập phân
            if ((e.KeyChar == '.' || e.KeyChar == ',') && txt.Text.IndexOfAny(new[] { '.', ',' }) < 0)
                return;
            // Cho phép dấu '-' ở đầu
            if (e.KeyChar == '-' && txt.SelectionStart == 0 && !txt.Text.Contains("-"))
                return;
            e.Handled = true;
        }

        // Mức 1: ErrorProvider báo lỗi khi dữ liệu không hợp lệ
        private bool KiemTra(TextBox txt)
        {
            float x;
            if (txt.Text.Trim() == "")
            {
                errorProvider1.SetError(txt, "Không được để trống!");
                return false;
            }
            if (!DocSo(txt.Text, out x))
            {
                errorProvider1.SetError(txt, "Phải nhập một số!");
                return false;
            }
            errorProvider1.SetError(txt, "");
            return true;
        }

        private void txtSo_Validating(object sender, CancelEventArgs e)
        {
            KiemTra((TextBox)sender);
        }

        private void txtSo_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.SetError((TextBox)sender, "");
            txt_KetQua.Text = "";
        }

        // Tính kết quả theo phép toán đang chọn, trả về null nếu không tính được
        private string TinhKetQua()
        {
            bool ok = KiemTra(txt_a);
            ok = KiemTra(txt_b) && ok;
            if (!ok)
                return null;

            float a, b;
            DocSo(txt_a.Text, out a);
            DocSo(txt_b.Text, out b);
            TinhToan dt = new TinhToan(a, b);

            if (rdo_cong.Checked)
                return a + " + " + b + " = " + dt.Cong();
            if (rdo_tru.Checked)
                return a + " - " + b + " = " + dt.Tru();
            if (rdo_nhan.Checked)
                return a + " x " + b + " = " + dt.Nhan();
            if (rdo_chia.Checked)
            {
                if (!dt.ChiaDuoc())
                {
                    errorProvider1.SetError(txt_b, "Không chia được cho 0!");
                    return "Phép chia bị lỗi!";
                }
                return a + " / " + b + " = " + dt.Chia();
            }
            return null;
        }

        // Click chọn radio button thì tính và xuất kết quả vào textbox Kết quả
        private void rdoPhepToan_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked)
                txt_KetQua.Text = TinhKetQua() ?? "";
        }

        private void btn_Tinh_Click(object sender, EventArgs e)
        {
            if (!rdo_cong.Checked && !rdo_tru.Checked && !rdo_nhan.Checked && !rdo_chia.Checked)
            {
                MessageBox.Show("Hãy chọn một phép toán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string kq = TinhKetQua();
            if (kq == null)
            {
                MessageBox.Show("Dữ liệu nhập vào không hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            txt_KetQua.Text = kq;
            MessageBox.Show("Kết quả là: \n" + kq, "Kết quả");
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Hỏi xác nhận trước khi đóng Form
        private void FrmTinhToan_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn đóng form không?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
    }
}
