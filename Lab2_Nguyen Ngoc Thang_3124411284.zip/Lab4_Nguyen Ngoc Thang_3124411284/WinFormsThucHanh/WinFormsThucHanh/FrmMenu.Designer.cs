﻿namespace WinFormsThucHanh
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnBaiMau1 = new System.Windows.Forms.Button();
            this.btnBaiMau2 = new System.Windows.Forms.Button();
            this.btnPhuongTrinh = new System.Windows.Forms.Button();
            this.btnMang = new System.Windows.Forms.Button();
            this.btnCafe = new System.Windows.Forms.Button();
            this.btnKhachSan = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(45, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Size = new System.Drawing.Size(0, 0);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "THỰC HÀNH WINDOWS FORM {2}";
            // 
            // btnBaiMau1
            // 
            this.btnBaiMau1.Location = new System.Drawing.Point(30, 60);
            this.btnBaiMau1.Name = "btnBaiMau1";
            this.btnBaiMau1.Size = new System.Drawing.Size(340, 40);
            this.btnBaiMau1.TabIndex = 1;
            this.btnBaiMau1.Text = "Tính toán hai số";
            this.btnBaiMau1.UseVisualStyleBackColor = true;
            this.btnBaiMau1.Click += new System.EventHandler(this.btnBaiMau1_Click);
            // 
            // btnBaiMau2
            // 
            this.btnBaiMau2.Location = new System.Drawing.Point(30, 110);
            this.btnBaiMau2.Name = "btnBaiMau2";
            this.btnBaiMau2.Size = new System.Drawing.Size(340, 40);
            this.btnBaiMau2.TabIndex = 2;
            this.btnBaiMau2.Text = " Định dạng Label";
            this.btnBaiMau2.UseVisualStyleBackColor = true;
            this.btnBaiMau2.Click += new System.EventHandler(this.btnBaiMau2_Click);
            // 
            // btnPhuongTrinh
            // 
            this.btnPhuongTrinh.Location = new System.Drawing.Point(30, 160);
            this.btnPhuongTrinh.Name = "btnPhuongTrinh";
            this.btnPhuongTrinh.Size = new System.Drawing.Size(340, 40);
            this.btnPhuongTrinh.TabIndex = 3;
            this.btnPhuongTrinh.Text =  "Giải phương trình";
            this.btnPhuongTrinh.UseVisualStyleBackColor = true;
            this.btnPhuongTrinh.Click += new System.EventHandler(this.btnPhuongTrinh_Click);
            // 
            // btnMang
            // 
            this.btnMang.Location = new System.Drawing.Point(30, 210);
            this.btnMang.Name = "btnMang";
            this.btnMang.Size = new System.Drawing.Size(340, 40);
            this.btnMang.TabIndex = 4;
            this.btnMang.Text = "Mảng một chiều";
            this.btnMang.UseVisualStyleBackColor = true;
            this.btnMang.Click += new System.EventHandler(this.btnMang_Click);
            // 
            // btnCafe
            // 
            this.btnCafe.Location = new System.Drawing.Point(30, 260);
            this.btnCafe.Name = "btnCafe";
            this.btnCafe.Size = new System.Drawing.Size(340, 40);
            this.btnCafe.TabIndex = 5;
            this.btnCafe.Text = "Quán Cafe Sinh Viên";
            this.btnCafe.UseVisualStyleBackColor = true;
            this.btnCafe.Click += new System.EventHandler(this.btnCafe_Click);
            // 
            // btnKhachSan
            // 
            this.btnKhachSan.Location = new System.Drawing.Point(30, 310);
            this.btnKhachSan.Name = "btnKhachSan";
            this.btnKhachSan.Size = new System.Drawing.Size(340, 40);
            this.btnKhachSan.TabIndex = 6;
            this.btnKhachSan.Text = "Khách sạn Thanh Thanh";
            this.btnKhachSan.UseVisualStyleBackColor = true;
            this.btnKhachSan.Click += new System.EventHandler(this.btnKhachSan_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(30, 370);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(340, 40);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 425);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnBaiMau1);
            this.Controls.Add(this.btnBaiMau2);
            this.Controls.Add(this.btnPhuongTrinh);
            this.Controls.Add(this.btnMang);
            this.Controls.Add(this.btnCafe);
            this.Controls.Add(this.btnKhachSan);
            this.Controls.Add(this.btnThoat);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài thực hành Windows Form cơ bản {2}";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMenu_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnBaiMau1;
        private System.Windows.Forms.Button btnBaiMau2;
        private System.Windows.Forms.Button btnPhuongTrinh;
        private System.Windows.Forms.Button btnMang;
        private System.Windows.Forms.Button btnCafe;
        private System.Windows.Forms.Button btnKhachSan;
        private System.Windows.Forms.Button btnThoat;
    }
}
