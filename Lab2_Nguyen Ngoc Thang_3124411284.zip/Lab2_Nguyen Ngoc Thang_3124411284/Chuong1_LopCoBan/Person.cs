using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong1
{
    // Bài 1.3: Lớp Person
    public class Person
    {
        // ===== Field =====
        private string id;
        private string name;
        private int yob;    // năm sinh
        private int yod;    // năm mất (0 = còn sống)

        // ===== Constructor =====
        public Person()                                  // default constructor
        {
            id = "";
            name = "";
            yob = 0;
            yod = 0;
        }

        public Person(string id, string name, int yob, int yod = 0)
        {
            this.id = id;
            this.name = name;
            this.yob = yob;
            this.yod = yod;
        }

        public Person(Person other)                      // copy constructor
            : this(other.id, other.name, other.yob, other.yod) { }

        // ===== Property =====
        public string Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public int Yob { get => yob; set => yob = value; }
        public int Yod { get => yod; set => yod = value; }

        // ===== Method =====
        public void Input()
        {
            id = InputHelper.NhapChuoi("  Mã (id): ");
            name = InputHelper.NhapChuoi("  Họ tên: ");
            yob = InputHelper.NhapSoNguyen("  Năm sinh: ", 1, DateTime.Now.Year);
            while (true)
            {
                yod = InputHelper.NhapSoNguyen("  Năm mất (nhập 0 nếu còn sống): ", 0, DateTime.Now.Year);
                if (yod == 0 || yod >= yob) break;
                Console.WriteLine("  -> Năm mất phải lớn hơn hoặc bằng năm sinh.");
            }
        }

        public void Output() => Console.WriteLine(this);

        public bool IsLiving() => yod == 0;

        public static string TieuDe => $"{"Mã",-8}{"Họ tên",-25}{"Năm sinh",-10}Tình trạng";

        public override string ToString() =>
            $"{id,-8}{name,-25}{yob,-10}{(IsLiving() ? "Còn sống" : $"Mất năm {yod}")}";
    }
}
