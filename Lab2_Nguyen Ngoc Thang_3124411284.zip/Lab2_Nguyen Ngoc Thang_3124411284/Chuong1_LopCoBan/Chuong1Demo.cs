using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong1
{
    
    public static class Chuong1Demo
    {
        public static void Bai1_1()
        {
            SinhVien sv = new SinhVien();
            sv.Nhap();
            Console.WriteLine();
            sv.Xuat();
        }

        public static void Bai1_2()
        {
            Point A = new Point(), B = new Point();
            Console.WriteLine("Nhập điểm A:");
            A.Input();
            Console.WriteLine("Nhập điểm B:");
            B.Input();

            Console.WriteLine($"\nA = {A}, B = {B}");
            Console.WriteLine($"A + B = {A + B}");
            Console.WriteLine($"A - B = {A - B}");
            Console.WriteLine($"-A    = {-A}");

            Console.WriteLine("\n(a) Khoảng cách AB:");
            Console.WriteLine($"  Phương thức thành viên  A.KhoangCach(B)        = {A.KhoangCach(B):0.###}");
            Console.WriteLine($"  Phương thức tĩnh        Point.KhoangCach(A, B) = {Point.KhoangCach(A, B):0.###}");

            Console.WriteLine("\n(b) Trung điểm I của AB:");
            Console.WriteLine($"  Phương thức thành viên  A.TrungDiem(B)         = {A.TrungDiem(B)}");
            Console.WriteLine($"  Phương thức tĩnh        Point.TrungDiem(A, B)  = {Point.TrungDiem(A, B)}");
        }

        public static void Bai1_3()
        {
            Person p = new Person();
            Console.WriteLine("Nhập thông tin người:");
            p.Input();

            Person banSao = new Person(p);      // copy constructor

            Console.WriteLine("\n" + Person.TieuDe);
            p.Output();
            Console.WriteLine($"\nIsLiving() = {p.IsLiving()}");

            Console.WriteLine("\nBản sao tạo bằng copy constructor:");
            banSao.Output();
        }

        public static void Bai1_4()
        {
            PhanSo a = new PhanSo(), b = new PhanSo();
            Console.WriteLine("Nhập phân số a:");
            a.Nhap();
            Console.WriteLine("Nhập phân số b:");
            b.Nhap();

            Console.WriteLine($"\na = {a}, b = {b}");

            Console.WriteLine("\nToán tử một ngôi:");
            Console.WriteLine($"  +a = {+a}");
            Console.WriteLine($"  -a = {-a}");

            Console.WriteLine("\nToán tử hai ngôi:");
            Console.WriteLine($"  a + b = {a + b}");
            Console.WriteLine($"  a - b = {a - b}");
            Console.WriteLine($"  a * b = {a * b}");
            Console.WriteLine(b == new PhanSo() ? "  a / b = không chia được (b = 0)" : $"  a / b = {a / b}");

            Console.WriteLine("\nToán tử so sánh:");
            Console.WriteLine($"  a >  b : {a > b}");
            Console.WriteLine($"  a <  b : {a < b}");
            Console.WriteLine($"  a >= b : {a >= b}");
            Console.WriteLine($"  a <= b : {a <= b}");
            Console.WriteLine($"  a == b : {a == b}");
            Console.WriteLine($"  a != b : {a != b}");
        }

        public static void Bai1_5()
        {
            DonThuc p = new DonThuc();
            Console.WriteLine("Nhập đơn thức P(x) = a.x^n:");
            p.Nhap();
            double x = InputHelper.NhapSoThuc("Nhập giá trị x = ");

            DonThuc q = p.DaoHam();

            Console.WriteLine($"\nP(x)  = {p}");
            Console.WriteLine($"(a) P({x})  = {p.GiaTri(x)}");
            Console.WriteLine($"(b) P'(x) = {q}");
            Console.WriteLine($"    P'({x}) = {q.GiaTri(x)}");
        }
    }
}
