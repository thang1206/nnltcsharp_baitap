using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong1
{
    // Bài 1.5: Lớp Đơn thức P(x) = a.x^n
    public class DonThuc
    {
        
        private double a;   // hệ số (số thực)
        private int n;      // số mũ (nguyên không âm)

        public DonThuc()
        {
            a = 0;
            n = 0;
        }
        public DonThuc(double a, int n)
        {
            if (n < 0) throw new ArgumentException("Số mũ phải >= 0.");
            this.a = a;
            this.n = n;
        }
        public DonThuc(DonThuc other) : this(other.a, other.n) { }
        public double A { get => a; set => a = value; }

        public int N
        {
            get => n;
            set
            {
                if (value < 0) throw new ArgumentException("Số mũ phải >= 0.");
                n = value;
            }
        }

        // ===== Method =====
        public void Nhap()
        {
            a = InputHelper.NhapSoThuc("  Hệ số a = ");
            n = InputHelper.NhapSoNguyen("  Số mũ n (n >= 0) = ", 0);
        }

        // (a) Giá trị P(x) = a.x^n
        public double GiaTri(double x) => a * Math.Pow(x, n);

        // (b) Đạo hàm: P'(x) = a.n.x^(n-1)
        public DonThuc DaoHam() => n == 0 ? new DonThuc(0, 0) : new DonThuc(a * n, n - 1);

        public override string ToString()
        {
            if (a == 0) return "0";
            if (n == 0) return $"{a}";
            string heSo = a == 1 ? "" : a == -1 ? "-" : $"{a}";
            string bien = n == 1 ? "x" : $"x^{n}";
            return heSo + bien;
        }
    }
}
