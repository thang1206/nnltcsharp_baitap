using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong1
{
    // Bài 1.2: Lớp Point
    public class Point
    {
        // ===== Field =====
        private double x, y;

        // ===== Constructor =====
        public Point()                       // default: x = y = 0
        {
            x = 0;
            y = 0;
        }

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public Point(Point p) : this(p.x, p.y) { }

        // ===== Property =====
        public double X { get => x; set => x = value; }
        public double Y { get => y; set => y = value; }

        // ===== Nhập / Xuất =====
        public void Input()
        {
            x = InputHelper.NhapSoThuc("  x = ");
            y = InputHelper.NhapSoThuc("  y = ");
        }

        public void Output() => Console.WriteLine(this);

        public override string ToString() => $"({x}, {y})";

        // ===== Phép toán =====
        public static Point operator +(Point a, Point b) => new Point(a.x + b.x, a.y + b.y);
        public static Point operator -(Point a, Point b) => new Point(a.x - b.x, a.y - b.y);
        public static Point operator -(Point a) => new Point(-a.x, -a.y);   // lấy âm

        // ===== (a) Khoảng cách giữa 2 điểm =====
        // Cách 1: phương thức thành viên  ->  A.KhoangCach(B)
        public double KhoangCach(Point other)
        {
            double dx = x - other.x, dy = y - other.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        // Cách 2: phương thức tĩnh  ->  Point.KhoangCach(A, B)
        public static double KhoangCach(Point a, Point b)
        {
            double dx = a.x - b.x, dy = a.y - b.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        // ===== (b) Trung điểm của 2 điểm =====
        // Cách 1: phương thức thành viên  ->  A.TrungDiem(B)
        public Point TrungDiem(Point other) =>
            new Point((x + other.x) / 2, (y + other.y) / 2);

        // Cách 2: phương thức tĩnh  ->  Point.TrungDiem(A, B)
        public static Point TrungDiem(Point a, Point b) =>
            new Point((a.x + b.x) / 2, (a.y + b.y) / 2);
    }
}
