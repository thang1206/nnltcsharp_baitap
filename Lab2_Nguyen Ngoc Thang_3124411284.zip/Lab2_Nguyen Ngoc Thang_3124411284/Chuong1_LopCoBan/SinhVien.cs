using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong1
{
    // Bài 1.1: Tính tuổi 1 sinh viên
    public class SinhVien
    {
        // ===== Field =====
        private string hoTen;
        private int namSinh;

        // ===== Constructor =====
        public SinhVien()
        {
            hoTen = "";
            namSinh = DateTime.Now.Year;
        }

        public SinhVien(string hoTen, int namSinh)
        {
            this.hoTen = hoTen;
            this.namSinh = namSinh;
        }

        public SinhVien(SinhVien other) : this(other.hoTen, other.namSinh) { }

        // ===== Property =====
        public string HoTen
        {
            get => hoTen;
            set => hoTen = value;
        }

        public int NamSinh
        {
            get => namSinh;
            set
            {
                if (value < 1900 || value > DateTime.Now.Year)
                    throw new ArgumentException("Năm sinh không hợp lệ.");
                namSinh = value;
            }
        }

        // ===== Method =====
        public void Nhap()
        {
            hoTen = InputHelper.NhapChuoi("Nhập họ tên: ");
            namSinh = InputHelper.NhapSoNguyen("Nhập năm sinh: ", 1900, DateTime.Now.Year);
        }

        public int TinhTuoi() => DateTime.Now.Year - namSinh;

        public void Xuat() => Console.WriteLine(this);

        public override string ToString() =>
            $"Sinh viên {hoTen}, sinh năm {namSinh}, năm nay {TinhTuoi()} tuổi.";
    }
}
