using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong1
{
    // Bài 1.4: Lớp Phân số
    public class PhanSo
    {
        // ===== Field =====
        private int tu, mau;     // luôn giữ ở dạng tối giản, mẫu > 0

        // ===== Constructor =====
        public PhanSo()                          
        {
            tu = 0;
            mau = 1;
        }

        public PhanSo(int tu)                   
        {
            this.tu = tu;
            mau = 1;
        }

        public PhanSo(int tu, int mau)
        {
            if (mau == 0) throw new DivideByZeroException("Mẫu số phải khác 0.");
            this.tu = tu;
            this.mau = mau;
            RutGon();
        }

        public PhanSo(PhanSo other)             
        {
            tu = other.tu;
            mau = other.mau;
        }

        // ===== Property =====
        public int Tu
        {
            get => tu;
            set { tu = value; RutGon(); }
        }

        public int Mau
        {
            get => mau;
            set
            {
                if (value == 0) throw new DivideByZeroException("Mẫu số phải khác 0.");
                mau = value;
                RutGon();
            }
        }

        public double GiaTri => (double)tu / mau;

        // ===== Method =====
        private static int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (b != 0)
                (a, b) = (b, a % b);
            return a;
        }

        public void RutGon()
        {
            if (mau < 0) { tu = -tu; mau = -mau; }
            int u = UCLN(tu, mau);
            if (u > 1) { tu /= u; mau /= u; }
        }

        public void Nhap()
        {
            tu = InputHelper.NhapSoNguyen("  Tử số: ");
            while (true)
            {
                mau = InputHelper.NhapSoNguyen("  Mẫu số: ");
                if (mau != 0) break;
                Console.WriteLine("  -> Mẫu số phải khác 0.");
            }
            RutGon();
        }

        public override string ToString() => mau == 1 ? $"{tu}" : $"{tu}/{mau}";

        // ===== Toán tử một ngôi =====
        public static PhanSo operator +(PhanSo a) => new PhanSo(a);
        public static PhanSo operator -(PhanSo a) => new PhanSo(-a.tu, a.mau);

        // ===== Toán tử hai ngôi =====
        public static PhanSo operator +(PhanSo a, PhanSo b) =>
            new PhanSo(a.tu * b.mau + b.tu * a.mau, a.mau * b.mau);

        public static PhanSo operator -(PhanSo a, PhanSo b) =>
            new PhanSo(a.tu * b.mau - b.tu * a.mau, a.mau * b.mau);

        public static PhanSo operator *(PhanSo a, PhanSo b) =>
            new PhanSo(a.tu * b.tu, a.mau * b.mau);

        public static PhanSo operator /(PhanSo a, PhanSo b)
        {
            if (b.tu == 0) throw new DivideByZeroException("Không thể chia cho phân số 0.");
            return new PhanSo(a.tu * b.mau, a.mau * b.tu);
        }

        // ===== Toán tử so sánh =====
        // Mẫu luôn dương nên so sánh a/b với c/d <=> so sánh a*d với c*b
        private static int SoSanh(PhanSo a, PhanSo b) =>
            ((long)a.tu * b.mau).CompareTo((long)b.tu * a.mau);

        public static bool operator >(PhanSo a, PhanSo b) => SoSanh(a, b) > 0;
        public static bool operator <(PhanSo a, PhanSo b) => SoSanh(a, b) < 0;
        public static bool operator >=(PhanSo a, PhanSo b) => SoSanh(a, b) >= 0;
        public static bool operator <=(PhanSo a, PhanSo b) => SoSanh(a, b) <= 0;

        public static bool operator ==(PhanSo? a, PhanSo? b)
        {
            if (ReferenceEquals(a, b)) return true;
            if (a is null || b is null) return false;
            return a.tu == b.tu && a.mau == b.mau;     // cả 2 đều tối giản
        }

        public static bool operator !=(PhanSo? a, PhanSo? b) => !(a == b);

        // Bắt buộc override khi overload == và !=
        public override bool Equals(object? obj) => obj is PhanSo p && this == p;
        public override int GetHashCode() => HashCode.Combine(tu, mau);
    }
}
