using OOP_CSharp.Chuong1;
using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.6: Lớp chứa n phân số
    public class DayPhanSo
    {
        private List<PhanSo> ds;

        public DayPhanSo()
        {
            ds = new List<PhanSo>();
        }

        public DayPhanSo(DayPhanSo other)
        {
            ds = new List<PhanSo>();
            foreach (PhanSo p in other.ds)
                ds.Add(new PhanSo(p));
        }

        public int Count => ds.Count;

        public PhanSo this[int i]
        {
            get => ds[i];
            set => ds[i] = value;
        }

        public void Add(PhanSo p) => ds.Add(p);

        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số phân số n: ", 0);
            ds.Clear();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Phân số thứ {i + 1}:");
                PhanSo p = new PhanSo();
                p.Nhap();
                ds.Add(p);
            }
        }

        public void Xuat() => Console.WriteLine(ds.Count == 0 ? "(rỗng)" : string.Join("   ", ds));

        // Tổng n phân số (dùng toán tử + của lớp PhanSo)
        public PhanSo Tong()
        {
            PhanSo s = new PhanSo();
            foreach (PhanSo p in ds)
                s = s + p;
            return s;
        }
    }
}
