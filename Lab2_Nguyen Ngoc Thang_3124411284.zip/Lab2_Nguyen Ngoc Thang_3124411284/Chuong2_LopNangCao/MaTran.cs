using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.4: Lớp chứa mảng 2 chiều n x m
    public class MaTran
    {
        private int[,] a;

        // ===== a. Các loại constructor =====
        public MaTran()
        {
            a = new int[0, 0];
        }

        public MaTran(int n, int m)
        {
            a = new int[n, m];
        }

        public MaTran(MaTran other)
        {
            a = (int[,])other.a.Clone();
        }

        public int SoDong => a.GetLength(0);
        public int SoCot => a.GetLength(1);

        // ===== b. Indexer truy cập phần tử (i, j) =====
        public int this[int i, int j]
        {
            get
            {
                KiemTraChiSo(i, j);
                return a[i, j];
            }
            set
            {
                KiemTraChiSo(i, j);
                a[i, j] = value;
            }
        }

        private void KiemTraChiSo(int i, int j)
        {
            if (i < 0 || i >= SoDong || j < 0 || j >= SoCot)
                throw new IndexOutOfRangeException($"Vị trí ({i}, {j}) không hợp lệ.");
        }

        // ===== c. Nhập / Xuất =====
        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số dòng n: ", 1);
            int m = InputHelper.NhapSoNguyen("Nhập số cột m: ", 1);
            a = new int[n, m];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    a[i, j] = InputHelper.NhapSoNguyen($"  a[{i},{j}] = ");
        }

        public void Xuat()
        {
            for (int i = 0; i < SoDong; i++)
            {
                for (int j = 0; j < SoCot; j++)
                    Console.Write($"{a[i, j],6}");
                Console.WriteLine();
            }
        }

        // ===== d. Tìm các số nguyên tố =====
        public static bool LaSoNguyenTo(int x)
        {
            if (x < 2) return false;
            for (int i = 2; (long)i * i <= x; i++)
                if (x % i == 0) return false;
            return true;
        }

        public List<int> TimSoNguyenTo()
        {
            List<int> kq = new List<int>();
            for (int i = 0; i < SoDong; i++)
                for (int j = 0; j < SoCot; j++)
                    if (LaSoNguyenTo(a[i, j]))
                        kq.Add(a[i, j]);
            return kq;
        }
    }
}
