using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.7: Phòng ban gồm n nhân viên
    public class PhongBan
    {
        private List<NhanVien> ds;

        public PhongBan()
        {
            ds = new List<NhanVien>();
        }

        public PhongBan(PhongBan other)
        {
            ds = new List<NhanVien>();
            foreach (NhanVien nv in other.ds)
                ds.Add(new NhanVien(nv));
        }

        public int Count => ds.Count;

        public NhanVien this[int i]
        {
            get => ds[i];
            set => ds[i] = value;
        }

        public void Add(NhanVien nv) => ds.Add(nv);

        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số nhân viên: ", 0);
            ds.Clear();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Nhân viên thứ {i + 1}:");
                NhanVien nv = new NhanVien();
                nv.Nhap();
                ds.Add(nv);
            }
        }

        public void Xuat()
        {
            Console.WriteLine(NhanVien.TieuDe);
            foreach (NhanVien nv in ds)
                Console.WriteLine(nv);
        }

        public double TongLuong()
        {
            double tong = 0;
            foreach (NhanVien nv in ds)
                tong += nv.TinhLuong();
            return tong;
        }
    }
}
