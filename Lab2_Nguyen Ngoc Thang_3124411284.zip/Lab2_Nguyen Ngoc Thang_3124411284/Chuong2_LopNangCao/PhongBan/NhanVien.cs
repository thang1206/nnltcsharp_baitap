using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.7: Nhân viên trong phòng ban
    public class NhanVien
    {
        public const double TIEN_TRU_MOT_NGAY = 100_000;

        private string hoTen;
        private double mucLuong;
        private int soNgayVang;

        public NhanVien()
        {
            hoTen = "";
            mucLuong = 0;
            soNgayVang = 0;
        }

        public NhanVien(string hoTen, double mucLuong, int soNgayVang)
        {
            this.hoTen = hoTen;
            this.mucLuong = mucLuong;
            this.soNgayVang = soNgayVang;
        }

        public NhanVien(NhanVien other) : this(other.hoTen, other.mucLuong, other.soNgayVang) { }

        public string HoTen { get => hoTen; set => hoTen = value; }
        public double MucLuong { get => mucLuong; set => mucLuong = value; }
        public int SoNgayVang { get => soNgayVang; set => soNgayVang = value; }

        public void Nhap()
        {
            hoTen = InputHelper.NhapChuoi("  Họ tên: ");
            do
            {
                mucLuong = InputHelper.NhapSoThuc("  Mức lương: ");
            } while (mucLuong < 0);
            soNgayVang = InputHelper.NhapSoNguyen("  Số ngày vắng: ", 0, 31);
        }

        // Lương thực nhận = mức lương - số ngày vắng x 100.000 (không âm)
        public double TinhLuong() => Math.Max(0, mucLuong - soNgayVang * TIEN_TRU_MOT_NGAY);

        public static string TieuDe =>
            $"{"Họ tên",-25}{"Mức lương",15}{"Ngày vắng",12}{"Thực lãnh",15}";

        public override string ToString() =>
            $"{hoTen,-25}{mucLuong,15:N0}{soNgayVang,12}{TinhLuong(),15:N0}";
    }
}
