using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.3: Lớp chứa mảng 1 chiều (dãy n số nguyên)
    public class DaySoNguyen
    {
        private int[] a;

        // ===== a. Các loại constructor =====
        public DaySoNguyen()                       // mặc định: dãy rỗng
        {
            a = new int[0];
        }

        public DaySoNguyen(int n)                  // dãy n phần tử = 0
        {
            a = new int[n];
        }

        public DaySoNguyen(int[] arr)              // từ mảng có sẵn
        {
            a = (int[])arr.Clone();
        }

        public DaySoNguyen(DaySoNguyen other) : this(other.a) { }   // sao chép

        public int Length => a.Length;

        // ===== b. Indexer =====
        public int this[int i]
        {
            get
            {
                KiemTraChiSo(i);
                return a[i];
            }
            set
            {
                KiemTraChiSo(i);
                a[i] = value;
            }
        }

        private void KiemTraChiSo(int i)
        {
            if (i < 0 || i >= a.Length)
                throw new IndexOutOfRangeException($"Chỉ số {i} nằm ngoài [0, {a.Length - 1}].");
        }

        // ===== c. Nhập / Xuất =====
        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số phần tử n: ", 0);
            a = new int[n];
            for (int i = 0; i < n; i++)
                a[i] = InputHelper.NhapSoNguyen($"  a[{i}] = ");
        }

        public void Xuat() => Console.WriteLine(a.Length == 0 ? "(rỗng)" : string.Join(" ", a));

        // ===== d. Tìm các số chẵn =====
        public DaySoNguyen TimSoChan()
        {
            List<int> chan = new List<int>();
            foreach (int x in a)
                if (x % 2 == 0)
                    chan.Add(x);
            return new DaySoNguyen(chan.ToArray());
        }
    }
}
