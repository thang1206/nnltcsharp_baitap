using OOP_CSharp.Chuong1;
using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.2: Lớp PersonList quản lý nhân khẩu
    public class PersonList
    {
        private List<Person> ds;

        public PersonList()                             
        {
            ds = new List<Person>();
        }

        public PersonList(PersonList other)              
        {
            ds = new List<Person>();
            foreach (Person p in other.ds)
                ds.Add(new Person(p));
        }

        public int Count => ds.Count;

        public Person this[int i]
        {
            get => ds[i];
            set => ds[i] = value;
        }

        public void Add(Person x) => ds.Add(x);

        public void Input()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số người: ", 0);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Người thứ {i + 1}:");
                Person p = new Person();
                p.Input();
                Add(p);
            }
        }

        public void Output()
        {
            if (ds.Count == 0)
            {
                Console.WriteLine("  (Danh sách rỗng)");
                return;
            }
            Console.WriteLine(Person.TieuDe);
            foreach (Person p in ds)
                p.Output();
        }

        // Trả về PersonList gồm những người còn sống
        public PersonList LivingPeople()
        {
            PersonList kq = new PersonList();
            foreach (Person p in ds)
                if (p.IsLiving())
                    kq.Add(p);
            return kq;
        }
    }
}
