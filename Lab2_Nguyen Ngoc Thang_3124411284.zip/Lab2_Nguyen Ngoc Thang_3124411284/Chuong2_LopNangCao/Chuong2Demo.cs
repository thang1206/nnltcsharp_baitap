using OOP_CSharp.Chuong1;
using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Code chạy các bài chương 2 (được gọi từ menu trong Program.cs)
    public static class Chuong2Demo
    {
        public static void Bai2_1()
        {
            ArrayPoint ap = new ArrayPoint();
            ap.Nhap();
            Console.WriteLine("\nDanh sách điểm:");
            ap.Xuat();

            if (ap.Count == 0) return;

            int i = InputHelper.NhapSoNguyen($"\nNhập chỉ số i (0 - {ap.Count - 1}) để truy cập: ", 0, ap.Count - 1);
            Console.WriteLine($"Đọc bằng indexer:  ap[{i}] = {ap[i]}");

            ap[i] = -ap[i];     // ghi bằng indexer
            Console.WriteLine($"Gán ap[{i}] = -ap[{i}]  ->  ap[{i}] = {ap[i]}");
        }

        public static void Bai2_2()
        {
            PersonList ds = new PersonList();
            ds.Input();

            Console.WriteLine("\nDANH SÁCH NHÂN KHẨU:");
            ds.Output();

            Console.WriteLine("\nNHỮNG NGƯỜI CÒN SỐNG:");
            ds.LivingPeople().Output();
        }

        public static void Bai2_3()
        {
            DaySoNguyen ds = new DaySoNguyen();
            ds.Nhap();

            Console.Write("\nDãy vừa nhập: ");
            ds.Xuat();

            Console.Write("Các số chẵn:  ");
            ds.TimSoChan().Xuat();

            if (ds.Length > 0)
            {
                int i = InputHelper.NhapSoNguyen($"\nNhập chỉ số i (0 - {ds.Length - 1}): ", 0, ds.Length - 1);
                Console.WriteLine($"Phần tử thứ {i} (dùng indexer): {ds[i]}");
            }
        }

        public static void Bai2_4()
        {
            MaTran mt = new MaTran();
            mt.Nhap();

            Console.WriteLine("\nMa trận vừa nhập:");
            mt.Xuat();

            List<int> nt = mt.TimSoNguyenTo();
            Console.WriteLine(nt.Count == 0
                ? "\nMa trận không có số nguyên tố."
                : $"\nCác số nguyên tố: {string.Join(" ", nt)}");

            int i = InputHelper.NhapSoNguyen($"\nNhập dòng i (0 - {mt.SoDong - 1}): ", 0, mt.SoDong - 1);
            int j = InputHelper.NhapSoNguyen($"Nhập cột j (0 - {mt.SoCot - 1}): ", 0, mt.SoCot - 1);
            Console.WriteLine($"Phần tử tại ({i}, {j}) (dùng indexer): {mt[i, j]}");
        }

        public static void Bai2_5()
        {
            DaThuc p = new DaThuc();
            p.Nhap();

            Console.WriteLine();
            p.Xuat();

            int i = InputHelper.NhapSoNguyen($"\nNhập i (0 - {p.Bac}) để xem đơn thức thứ i: ", 0, p.Bac);
            Console.WriteLine($"Đơn thức thứ {i} (dùng indexer): {p[i]}");

            double x = InputHelper.NhapSoThuc("\nNhập giá trị x = ");
            Console.WriteLine($"P({x}) = {p.GiaTri(x)}");
        }

        public static void Bai2_6()
        {
            DayPhanSo ds = new DayPhanSo();
            ds.Nhap();

            Console.Write("\nDãy phân số: ");
            ds.Xuat();
            Console.WriteLine($"Tổng = {ds.Tong()}");
        }

        public static void Bai2_7()
        {
            PhongBan pb = new PhongBan();
            pb.Nhap();

            Console.WriteLine($"\nBẢNG LƯƠNG (trừ {NhanVien.TIEN_TRU_MOT_NGAY:N0} VNĐ / ngày vắng)");
            pb.Xuat();
            Console.WriteLine($"\nTổng lương phòng ban: {pb.TongLuong():N0} VNĐ");
        }
    }
}
