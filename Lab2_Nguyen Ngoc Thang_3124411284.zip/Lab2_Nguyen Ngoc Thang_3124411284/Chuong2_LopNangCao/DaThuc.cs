using System.Text;
using OOP_CSharp.Chuong1;
using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.5: Đa thức P(x) = a0.x^0 + a1.x^1 + ... + an.x^n  (gồm n+1 đơn thức)
    public class DaThuc
    {
        private DonThuc[] ds;     // ds[i] là đơn thức ai.x^i

        public DaThuc() : this(0) { }            // đa thức bậc 0: P(x) = 0

        public DaThuc(int bac)                   // đa thức bậc n, hệ số = 0
        {
            if (bac < 0) throw new ArgumentException("Bậc phải >= 0.");
            ds = new DonThuc[bac + 1];
            for (int i = 0; i <= bac; i++)
                ds[i] = new DonThuc(0, i);
        }

        public DaThuc(DaThuc other)             
        {
            ds = new DonThuc[other.ds.Length];
            for (int i = 0; i < ds.Length; i++)
                ds[i] = new DonThuc(other.ds[i]);
        }

        public int Bac => ds.Length - 1;

        // ===== truy cập đơn thức thứ i =====
        public DonThuc this[int i]
        {
            get
            {
                KiemTraChiSo(i);
                return ds[i];
            }
            set
            {
                KiemTraChiSo(i);
                ds[i] = new DonThuc(value.A, i);    // đơn thức thứ i luôn có số mũ i
            }
        }

        private void KiemTraChiSo(int i)
        {
            if (i < 0 || i > Bac)
                throw new IndexOutOfRangeException($"Chỉ số {i} nằm ngoài [0, {Bac}].");
        }

        // ===== Nhập / Xuất =====
        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập bậc n của đa thức: ", 0);
            ds = new DonThuc[n + 1];
            for (int i = 0; i <= n; i++)
                ds[i] = new DonThuc(InputHelper.NhapSoThuc($"  a{i} = "), i);
        }

        public void Xuat() => Console.WriteLine($"P(x) = {this}");

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = Bac; i >= 0; i--)          // in từ bậc cao xuống bậc thấp
            {
                double a = ds[i].A;
                if (a == 0) continue;

                if (sb.Length == 0)
                    sb.Append(ds[i]);
                else if (a > 0)
                    sb.Append(" + ").Append(ds[i]);
                else
                    sb.Append(" - ").Append(new DonThuc(-a, i));
            }
            return sb.Length == 0 ? "0" : sb.ToString();
        }

        // ===== Tính giá trị P(x) =====
        public double GiaTri(double x)
        {
            double tong = 0;
            foreach (DonThuc d in ds)
                tong += d.GiaTri(x);
            return tong;
        }
    }
}
