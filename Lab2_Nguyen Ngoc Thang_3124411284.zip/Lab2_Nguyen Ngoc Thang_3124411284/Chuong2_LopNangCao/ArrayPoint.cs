using System.Collections;
using OOP_CSharp.Chuong1;
using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong2
{
    // Bài 2.1: Lớp ArrayPoint lưu trữ các Point
    public class ArrayPoint
    {
        // Field: một ArrayList các Point
        private ArrayList ds;

        public ArrayPoint()
        {
            ds = new ArrayList();
        }

        public ArrayPoint(ArrayPoint other)
        {
            ds = new ArrayList();
            foreach (Point p in other.ds)
                ds.Add(new Point(p));
        }

        public int Count => ds.Count;

        // Indexer: truy cập Point thứ i
        public Point this[int i]
        {
            get
            {
                KiemTraChiSo(i);
                return (Point)ds[i]!;
            }
            set
            {
                KiemTraChiSo(i);
                ds[i] = value;
            }
        }

        private void KiemTraChiSo(int i)
        {
            if (i < 0 || i >= ds.Count)
                throw new IndexOutOfRangeException($"Chỉ số {i} nằm ngoài [0, {ds.Count - 1}].");
        }

        public void Add(Point p) => ds.Add(p);

        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số điểm: ", 0);
            ds.Clear();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Điểm thứ {i}:");
                Point p = new Point();
                p.Input();
                ds.Add(p);
            }
        }

        public void Xuat()
        {
            if (ds.Count == 0)
            {
                Console.WriteLine("  (Danh sách rỗng)");
                return;
            }
            for (int i = 0; i < ds.Count; i++)
                Console.WriteLine($"  P[{i}] = {this[i]}");
        }
    }
}
