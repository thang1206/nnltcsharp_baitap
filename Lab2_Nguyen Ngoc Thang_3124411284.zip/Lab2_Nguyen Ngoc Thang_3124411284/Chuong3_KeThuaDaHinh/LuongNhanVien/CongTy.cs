using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Bài 3.5: Công ty quản lý danh sách nhân viên (đa hình qua List<NhanVien>)
    public class CongTy
    {
        private List<NhanVien> ds = new List<NhanVien>();

        public void Add(NhanVien nv) => ds.Add(nv);

        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số nhân viên: ", 0);
            ds.Clear();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Nhân viên thứ {i + 1}:");
                int loai = InputHelper.NhapSoNguyen("  Bộ phận (1 - Kinh doanh, 2 - Sản xuất): ", 1, 2);

                NhanVien nv = loai == 1 ? new NVKinhDoanh() : (NhanVien)new NVSanXuat();
                nv.Nhap();        // gọi đúng Nhap() của lớp con
                ds.Add(nv);
            }
        }

        public void XuatBangLuong()
        {
            Console.WriteLine(NhanVien.TieuDe);
            foreach (NhanVien nv in ds)
                Console.WriteLine(nv);   // TinhLuong() của đúng lớp con được gọi
        }

        public double TongLuong()
        {
            double tong = 0;
            foreach (NhanVien nv in ds)
                tong += nv.TinhLuong();
            return tong;
        }
    }
}
