using OOP_CSharp.Utils;
namespace OOP_CSharp.Chuong3
{
    // Nhân viên kinh doanh: lương cơ bản + 500.000 / hợp đồng
    public class NVKinhDoanh : NhanVien
    {
        public const double THUONG_MOT_HOP_DONG = 500_000;

        private double luongCoBan;
        private int soHopDong;

        public NVKinhDoanh() { }

        public NVKinhDoanh(string maNV, string hoTen, double luongCoBan, int soHopDong)
            : base(maNV, hoTen)
        {
            this.luongCoBan = luongCoBan;
            this.soHopDong = soHopDong;
        }

        public double LuongCoBan { get => luongCoBan; set => luongCoBan = value; }
        public int SoHopDong { get => soHopDong; set => soHopDong = value; }

        public override string BoPhan => "Kinh doanh";

        public override void Nhap()
        {
            base.Nhap();
            do
            {
                luongCoBan = InputHelper.NhapSoThuc("  Lương cơ bản: ");
            } while (luongCoBan < 0);
            soHopDong = InputHelper.NhapSoNguyen("  Số hợp đồng ký được: ", 0);
        }

        public override double TinhLuong() => luongCoBan + soHopDong * THUONG_MOT_HOP_DONG;
    }
}
