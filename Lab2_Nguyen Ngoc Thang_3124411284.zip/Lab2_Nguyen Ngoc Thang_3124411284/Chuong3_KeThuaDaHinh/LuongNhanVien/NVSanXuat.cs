using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Nhân viên sản xuất: số sản phẩm x 1.000, trên 3.000 sản phẩm thưởng thêm 5%
    public class NVSanXuat : NhanVien
    {
        public const double DON_GIA = 1_000;
        public const int NGUONG_THUONG = 3_000;
        public const double TY_LE_THUONG = 0.05;

        private int soSanPham;

        public NVSanXuat() { }

        public NVSanXuat(string maNV, string hoTen, int soSanPham) : base(maNV, hoTen)
        {
            this.soSanPham = soSanPham;
        }

        public int SoSanPham { get => soSanPham; set => soSanPham = value; }

        public override string BoPhan => "Sản xuất";

        public override void Nhap()
        {
            base.Nhap();
            soSanPham = InputHelper.NhapSoNguyen("  Số sản phẩm: ", 0);
        }

        public override double TinhLuong()
        {
            double luong = soSanPham * DON_GIA;
            if (soSanPham > NGUONG_THUONG)
                luong += luong * TY_LE_THUONG;
            return luong;
        }
    }
}
