using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Bài 3.5: Lớp cơ sở trừu tượng cho các loại nhân viên
    public abstract class NhanVien
    {
        protected string maNV = "";
        protected string hoTen = "";

        protected NhanVien() { }

        protected NhanVien(string maNV, string hoTen)
        {
            this.maNV = maNV;
            this.hoTen = hoTen;
        }

        public string MaNV { get => maNV; set => maNV = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }

        public abstract string BoPhan { get; }

        // Đa hình: mỗi loại nhân viên tính lương theo cách riêng
        public abstract double TinhLuong();

        public virtual void Nhap()
        {
            maNV = InputHelper.NhapChuoi("  Mã nhân viên: ");
            hoTen = InputHelper.NhapChuoi("  Họ tên: ");
        }

        public static string TieuDe => $"{"Mã NV",-8}{"Họ tên",-25}{"Bộ phận",-12}{"Lương",15}";

        public override string ToString() => $"{maNV,-8}{hoTen,-25}{BoPhan,-12}{TinhLuong(),15:N0}";
    }
}
