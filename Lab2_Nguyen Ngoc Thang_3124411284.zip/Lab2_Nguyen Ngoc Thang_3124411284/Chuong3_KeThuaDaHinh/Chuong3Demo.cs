using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Code chạy các bài chương 3 (được gọi từ menu trong Program.cs)
    public static class Chuong3Demo
    {
        private static void InDanhSach<T>(string tieuDe, T[] a)
        {
            Console.WriteLine(tieuDe);
            foreach (T x in a)
                Console.WriteLine($"  {x}");
            Console.WriteLine();
        }

        public static void Bai3_1()
        {
            HocSinh[] ds = HocSinh.TaoDanhSachMau();
            InDanhSach("Danh sách ban đầu:", ds);

            Array.Sort(ds);                          // dùng IComparable<HocSinh>.CompareTo
            InDanhSach("Array.Sort(ds) – theo điểm tăng dần:", ds);

            Array.Sort(ds, new SoSanhTheoTen());     // dùng IComparer<HocSinh>
            InDanhSach("Array.Sort(ds, new SoSanhTheoTen()) – theo tên:", ds);
        }

        public static void Bai3_2()
        {
            HocSinh[] ds = HocSinh.TaoDanhSachMau();
            InDanhSach("Danh sách ban đầu:", ds);

            SortHelper.Sort(ds);                     // dùng ISoSanh<HocSinh>
            InDanhSach("SortHelper.Sort(ds) – theo điểm tăng dần:", ds);

            SortHelper.Sort(ds, new SoSanhTheoTen());  // dùng IBoSoSanh<HocSinh>
            InDanhSach("SortHelper.Sort(ds, new SoSanhTheoTen()) – theo tên:", ds);
        }

        // Hàm có cùng chữ ký với delegate HamSoSanh<HocSinh>
        private static int SoSanhTheoTen(HocSinh a, HocSinh b) =>
            string.Compare(a.Ten, b.Ten, StringComparison.CurrentCulture);

        public static void Bai3_3()
        {
            int[] so = { 5, 2, 9, 1, 7, 3 };
            Console.WriteLine($"Mảng số nguyên: {string.Join(" ", so)}");

            SortDelegate.Sort(so, (x, y) => x.CompareTo(y));
            Console.WriteLine($"  Tăng dần:     {string.Join(" ", so)}");

            SortDelegate.Sort(so, (x, y) => y.CompareTo(x));
            Console.WriteLine($"  Giảm dần:     {string.Join(" ", so)}\n");

            HocSinh[] ds = HocSinh.TaoDanhSachMau();
            InDanhSach("Danh sách học sinh ban đầu:", ds);

            SortDelegate.Sort(ds, (a, b) => b.DiemTB.CompareTo(a.DiemTB));   // lambda
            InDanhSach("Theo điểm giảm dần (lambda):", ds);

            SortDelegate.Sort(ds, SoSanhTheoTen);                             // tên phương thức
            InDanhSach("Theo tên (truyền phương thức SoSanhTheoTen):", ds);
        }

        public static void Bai3_4()
        {
            Console.WriteLine("1. Kế thừa: PTBac2Console : ConsoleMenu (kèm đăng ký sự kiện)");
            Console.WriteLine("2. Sự kiện: ConsoleMenu tổng quát + app.Choose += ...");
            int cach = InputHelper.NhapSoNguyen("Chọn cách chạy: ", 1, 2);
            Console.WriteLine();

            if (cach == 1)
            {
                PTBac2Console app = new PTBac2Console();
                app.Choose += x =>
                {
                    if (x == 3) Console.WriteLine("[Sự kiện Choose] Người dùng vừa chọn chức năng giải phương trình.");
                };
                app.Run();
            }
            else
            {
                ConsoleMenu menu = new ConsoleMenu("Menu", "Chức năng 1", "Chức năng 2");
                menu.Choose += x => Console.WriteLine($"(Hàm xử lý đăng ký qua sự kiện đang chạy chức năng {x})");
                menu.Run();
            }
        }

        public static void Bai3_5()
        {
            CongTy ct = new CongTy();
            ct.Nhap();

            Console.WriteLine("\nBẢNG LƯƠNG NHÂN VIÊN");
            ct.XuatBangLuong();
            Console.WriteLine($"\nTổng quỹ lương: {ct.TongLuong():N0} VNĐ");
        }

        public static void Bai3_6()
        {
            CuocThi ct = new CuocThi();
            ct.Nhap();

            Console.WriteLine("\nKẾT QUẢ CUỘC THI");
            ct.XuatKetQua();
        }
    }
}
