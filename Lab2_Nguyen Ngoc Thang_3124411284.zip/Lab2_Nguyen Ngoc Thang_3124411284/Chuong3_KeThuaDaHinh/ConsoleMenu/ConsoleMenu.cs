using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Bài 3.4: Lớp menu console tổng quát, mở rộng được bằng KẾ THỪA hoặc SỰ KIỆN
    public class ConsoleMenu
    {
        private readonly List<string> dsChucNang = new List<string>();

        public string TieuDe { get; set; }

        // Sự kiện phát ra khi người dùng chọn chức năng x
        public event Action<int>? Choose;

        public ConsoleMenu(string tieuDe = "Menu", params string[] chucNang)
        {
            TieuDe = tieuDe;
            dsChucNang.AddRange(chucNang);
        }

        public void ThemChucNang(string ten) => dsChucNang.Add(ten);

        // Lớp con override hàm này để xử lý; mặc định chỉ phát sự kiện Choose
        protected virtual void OnChoose(int x) => Choose?.Invoke(x);

        public void Run()
        {
            while (true)
            {
                Console.WriteLine(TieuDe);
                for (int i = 0; i < dsChucNang.Count; i++)
                    Console.WriteLine($"{i + 1}. {dsChucNang[i]}");
                Console.WriteLine("0. Thoát chương trình");

                int x = InputHelper.NhapSoNguyen("Thực hiện: ", 0, dsChucNang.Count);
                if (x == 0) break;

                Console.WriteLine($"Bạn thực hiện chức năng {x}");
                OnChoose(x);
                Console.WriteLine();
            }
        }
    }
}
