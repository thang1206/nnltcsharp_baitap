using OOP_CSharp.Chuong1;
using OOP_CSharp.Chuong2;
using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Bài 3.4: Áp dụng ConsoleMenu cho bài toán giải phương trình bậc 2 (bằng kế thừa)
    public class PTBac2Console : ConsoleMenu
    {
        private double a, b, c;
        private bool daNhap = false;

        public PTBac2Console()
            : base("===== GIẢI PHƯƠNG TRÌNH ax^2 + bx + c = 0 =====",
                   "Nhập hệ số a, b, c",
                   "Xuất phương trình",
                   "Giải phương trình")
        { }

        protected override void OnChoose(int x)
        {
            switch (x)
            {
                case 1:
                    Nhap();
                    break;
                case 2:
                    Console.WriteLine(daNhap ? ChuoiPhuongTrinh() : "Chưa nhập hệ số.");
                    break;
                case 3:
                    Console.WriteLine(daNhap ? Giai() : "Chưa nhập hệ số.");
                    break;
            }
            base.OnChoose(x);   // vẫn phát sự kiện Choose cho bên ngoài đăng ký
        }

        private void Nhap()
        {
            a = InputHelper.NhapSoThuc("  a = ");
            b = InputHelper.NhapSoThuc("  b = ");
            c = InputHelper.NhapSoThuc("  c = ");
            daNhap = true;
        }

        // Dùng lại lớp DaThuc (bài 2.5) để in vế trái cho đẹp, ví dụ: x^2 - 3x + 2
        public string ChuoiPhuongTrinh()
        {
            DaThuc p = new DaThuc(2);
            p[0] = new DonThuc(c, 0);
            p[1] = new DonThuc(b, 1);
            p[2] = new DonThuc(a, 2);
            return $"{p} = 0";
        }

        private static double Chuan(double v) => v == 0 ? 0 : v;   // tránh in ra "-0"

        public string Giai()
        {
            if (a == 0)
            {
                if (b == 0)
                    return c == 0 ? "Phương trình vô số nghiệm." : "Phương trình vô nghiệm.";
                return $"Phương trình bậc nhất, có nghiệm x = {Chuan(-c / b):0.####}";
            }

            double delta = b * b - 4 * a * c;
            if (delta < 0)
                return "Phương trình vô nghiệm (delta < 0).";
            if (delta == 0)
                return $"Phương trình có nghiệm kép x1 = x2 = {Chuan(-b / (2 * a)):0.####}";

            double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
            return $"Phương trình có 2 nghiệm phân biệt:\n  x1 = {Chuan(x1):0.####}\n  x2 = {Chuan(x2):0.####}";
        }
    }
}
