namespace OOP_CSharp.Chuong3
{
    // Thí sinh Chuyên: 3 bài lập trình + điểm thưởng tiếng Anh
    public class ThiSinhChuyen : ThiSinh
    {
        private double tiengAnh;

        public double TiengAnh { get => tiengAnh; set => tiengAnh = value; }

        public override string DoiTuong => "Chuyên";

        // 7 <= tiengAnh <= 8  : +1 điểm
        // 9 <= tiengAnh <= 10 : +2 điểm
        // (điểm lẻ giữa 8 và 9, ví dụ 8.5, được tính +1)
        public int DiemThuong
        {
            get
            {
                if (tiengAnh >= 9) return 2;
                if (tiengAnh >= 7) return 1;
                return 0;
            }
        }

        public override double TongDiem => TongBaiLapTrinh + DiemThuong;

        protected override string ThongTinRieng => $"TA={tiengAnh:0.##} (+{DiemThuong})";

        public override void Nhap()
        {
            base.Nhap();
            tiengAnh = NhapDiem("  Điểm tiếng Anh: ");
        }
    }
}
