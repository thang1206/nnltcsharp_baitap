using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Bài 3.6: Lớp cơ sở trừu tượng cho thí sinh
    public abstract class ThiSinh
    {
        protected string sbd = "";
        protected string hoten = "";
        protected double bai1, bai2, bai3;

        public string Sbd { get => sbd; set => sbd = value; }
        public string HoTen { get => hoten; set => hoten = value; }
        public double Bai1 { get => bai1; set => bai1 = value; }
        public double Bai2 { get => bai2; set => bai2 = value; }
        public double Bai3 { get => bai3; set => bai3 = value; }

        public abstract string DoiTuong { get; }

        // tongdiem: mỗi đối tượng tính theo cách riêng
        public abstract double TongDiem { get; }

        protected double TongBaiLapTrinh => bai1 + bai2 + bai3;

        // Thông tin riêng của từng đối tượng (điểm tiếng Anh / CSDL)
        protected abstract string ThongTinRieng { get; }

        protected static double NhapDiem(string thongBao)
        {
            while (true)
            {
                double d = InputHelper.NhapSoThuc(thongBao);
                if (d >= 0 && d <= 10) return d;
                Console.WriteLine("  -> Điểm phải nằm trong [0, 10].");
            }
        }

        public virtual void Nhap()
        {
            sbd = InputHelper.NhapChuoi("  Số báo danh: ");
            hoten = InputHelper.NhapChuoi("  Họ tên: ");
            bai1 = NhapDiem("  Điểm bài 1: ");
            bai2 = NhapDiem("  Điểm bài 2: ");
            bai3 = NhapDiem("  Điểm bài 3: ");
        }

        public static string TieuDe =>
            $"{"SBD",-8}{"Họ tên",-22}{"Đối tượng",-11}{"Bài 1",6}{"Bài 2",6}{"Bài 3",6}  {"Riêng",-16}{"Tổng",6}";

        public override string ToString() =>
            $"{sbd,-8}{hoten,-22}{DoiTuong,-11}{bai1,6:0.##}{bai2,6:0.##}{bai3,6:0.##}  {ThongTinRieng,-16}{TongDiem,6:0.##}";
    }
}
