using OOP_CSharp.Utils;

namespace OOP_CSharp.Chuong3
{
    // Bài 3.6: Cuộc thi gồm danh sách thí sinh
    public class CuocThi
    {
        private List<ThiSinh> ds = new List<ThiSinh>();

        public void Add(ThiSinh ts) => ds.Add(ts);

        public void Nhap()
        {
            int n = InputHelper.NhapSoNguyen("Nhập số thí sinh: ", 0);
            ds.Clear();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Thí sinh thứ {i + 1}:");
                int loai = InputHelper.NhapSoNguyen("  Đối tượng (1 - Chuyên, 2 - Siêu cúp): ", 1, 2);

                ThiSinh ts = loai == 1 ? new ThiSinhChuyen() : (ThiSinh)new ThiSinhSieuCup();
                ts.Nhap();
                ds.Add(ts);
            }
        }

        public void XuatKetQua()
        {
            Console.WriteLine(ThiSinh.TieuDe);
            foreach (ThiSinh ts in ds)
                Console.WriteLine(ts);
        }
    }
}
