namespace OOP_CSharp.Chuong3
{
    // Thí sinh Siêu cúp: tổng điểm 4 bài (3 bài lập trình + CSDL)
    public class ThiSinhSieuCup : ThiSinh
    {
        private double csdl;

        public double Csdl { get => csdl; set => csdl = value; }

        public override string DoiTuong => "Siêu cúp";

        public override double TongDiem => TongBaiLapTrinh + csdl;

        protected override string ThongTinRieng => $"CSDL={csdl:0.##}";

        public override void Nhap()
        {
            base.Nhap();
            csdl = NhapDiem("  Điểm CSDL: ");
        }
    }
}
