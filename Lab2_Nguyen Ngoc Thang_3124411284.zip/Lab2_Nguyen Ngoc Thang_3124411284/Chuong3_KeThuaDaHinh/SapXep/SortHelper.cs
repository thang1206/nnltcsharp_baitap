namespace OOP_CSharp.Chuong3
{
    // Bài 3.2: Sắp xếp mảng tổng quát bằng interface (mô phỏng Array.Sort)
    public static class SortHelper
    {
        // Mô phỏng Array.Sort(T[]) – phần tử tự biết so sánh
        public static void Sort<T>(T[] a) where T : ISoSanh<T>
        {
            for (int i = 0; i < a.Length - 1; i++)
                for (int j = i + 1; j < a.Length; j++)
                    if (a[i].SoSanh(a[j]) > 0)
                        (a[i], a[j]) = (a[j], a[i]);
        }

        // Mô phỏng Array.Sort(T[], IComparer<T>) – truyền bộ so sánh từ bên ngoài
        public static void Sort<T>(T[] a, IBoSoSanh<T> boSoSanh)
        {
            for (int i = 0; i < a.Length - 1; i++)
                for (int j = i + 1; j < a.Length; j++)
                    if (boSoSanh.SoSanh(a[i], a[j]) > 0)
                        (a[i], a[j]) = (a[j], a[i]);
        }
    }
}
