namespace OOP_CSharp.Chuong3
{
    // Bài 3.2: interface tự định nghĩa (tương tự IComparable<T>)
    // Kết quả: < 0 nếu this nhỏ hơn other, = 0 nếu bằng, > 0 nếu lớn hơn
    public interface ISoSanh<T>
    {
        int SoSanh(T other);
    }

    // Bộ so sánh bên ngoài (tương tự IComparer<T>)
    public interface IBoSoSanh<T>
    {
        int SoSanh(T a, T b);
    }
}
