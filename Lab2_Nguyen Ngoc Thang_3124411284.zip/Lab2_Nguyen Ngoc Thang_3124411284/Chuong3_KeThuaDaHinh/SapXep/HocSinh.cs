namespace OOP_CSharp.Chuong3
{
    // Lớp dùng chung để minh họa sắp xếp ở bài 3.1, 3.2, 3.3
    public class HocSinh : IComparable<HocSinh>, ISoSanh<HocSinh>
    {
        public string HoTen { get; set; }
        public double DiemTB { get; set; }
        public string Ten => HoTen.Split(' ', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "";
        public HocSinh(string hoTen, double diemTB)
        {
            HoTen = hoTen;
            DiemTB = diemTB;
        }

        // Bài 3.1: IComparable<T> của .NET -> Array.Sort() tự gọi CompareTo
        public int CompareTo(HocSinh? other) => other is null ? 1 : DiemTB.CompareTo(other.DiemTB);

        // Bài 3.2: interface ISoSanh<T> tự định nghĩa -> SortHelper.Sort() gọi SoSanh
        public int SoSanh(HocSinh other) => DiemTB.CompareTo(other.DiemTB);

        public override string ToString() => $"{HoTen,-22}{DiemTB,5:0.0}";

        public static HocSinh[] TaoDanhSachMau() => new[]
        {
            new HocSinh("Nguyễn Văn Bình", 7.5),
            new HocSinh("Trần Thị An",     8.8),
            new HocSinh("Lê Hoàng Dũng",   6.2),
            new HocSinh("Phạm Minh Châu",  9.1),
            new HocSinh("Võ Thanh Em",     5.4),
        };
    }
    public class SoSanhTheoTen : IComparer<HocSinh>, IBoSoSanh<HocSinh>
    {
        public int Compare(HocSinh? a, HocSinh? b) =>
            string.Compare(a?.Ten, b?.Ten, StringComparison.CurrentCulture);

        public int SoSanh(HocSinh a, HocSinh b) => Compare(a, b);
    }
}
