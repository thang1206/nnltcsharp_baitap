namespace OOP_CSharp.Chuong3
{
    // Bài 3.3: delegate mô tả một hàm so sánh 2 phần tử
    public delegate int HamSoSanh<T>(T a, T b);

    public static class SortDelegate
    {
        // Sắp xếp mảng tổng quát, cách so sánh được truyền vào qua delegate
        public static void Sort<T>(T[] a, HamSoSanh<T> soSanh)
        {
            for (int i = 0; i < a.Length - 1; i++)
                for (int j = i + 1; j < a.Length; j++)
                    if (soSanh(a[i], a[j]) > 0)
                        (a[i], a[j]) = (a[j], a[i]);
        }
    }
}
