using System.Globalization;
using System.Text;
using OOP_CSharp.Chuong1;
using OOP_CSharp.Chuong2;
using OOP_CSharp.Chuong3;
using OOP_CSharp.Utils;

namespace OOP_CSharp
{
    record Bai(string Ten, Action Chay);
    record Chuong(string Ten, Bai[] DsBai);

    internal class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            try { Console.InputEncoding = Encoding.Unicode; } catch { }
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

            Chuong[] dsChuong =
            {
                new Chuong("Chương 1 - Thiết kế lớp cơ bản", new[]
                {
                    new Bai("Bài 1.1 - Tính tuổi sinh viên", Chuong1Demo.Bai1_1),
                    new Bai("Bài 1.2 - Lớp Point",           Chuong1Demo.Bai1_2),
                    new Bai("Bài 1.3 - Lớp Person",          Chuong1Demo.Bai1_3),
                    new Bai("Bài 1.4 - Lớp Phân số",         Chuong1Demo.Bai1_4),
                    new Bai("Bài 1.5 - Lớp Đơn thức",        Chuong1Demo.Bai1_5),
                }),
                new Chuong("Chương 2 - Thiết kế lớp nâng cao", new[]
                {
                    new Bai("Bài 2.1 - ArrayPoint",           Chuong2Demo.Bai2_1),
                    new Bai("Bài 2.2 - PersonList",           Chuong2Demo.Bai2_2),
                    new Bai("Bài 2.3 - Dãy số nguyên",        Chuong2Demo.Bai2_3),
                    new Bai("Bài 2.4 - Mảng 2 chiều",         Chuong2Demo.Bai2_4),
                    new Bai("Bài 2.5 - Đa thức",              Chuong2Demo.Bai2_5),
                    new Bai("Bài 2.6 - Dãy phân số",          Chuong2Demo.Bai2_6),
                    new Bai("Bài 2.7 - Tổng lương phòng ban", Chuong2Demo.Bai2_7),
                }),
                new Chuong("Chương 3 - Kế thừa và đa hình", new[]
                {
                    new Bai("Bài 3.1 - Sắp xếp bằng Array.Sort()",     Chuong3Demo.Bai3_1),
                    new Bai("Bài 3.2 - Sắp xếp tổng quát (interface)", Chuong3Demo.Bai3_2),
                    new Bai("Bài 3.3 - Sắp xếp tổng quát (delegate)",  Chuong3Demo.Bai3_3),
                    new Bai("Bài 3.4 - ConsoleMenu / PT bậc 2",        Chuong3Demo.Bai3_4),
                    new Bai("Bài 3.5 - Tính lương nhân viên",          Chuong3Demo.Bai3_5),
                    new Bai("Bài 3.6 - Tính điểm thí sinh",            Chuong3Demo.Bai3_6),
                }),
            };

            while (true)
            {
                XoaManHinh();
                Console.WriteLine("========== LẬP TRÌNH HƯỚNG ĐỐI TƯỢNG C# ==========");
                for (int i = 0; i < dsChuong.Length; i++)
                    Console.WriteLine($"{i + 1}. {dsChuong[i].Ten}");
                Console.WriteLine("0. Thoát chương trình");
                Console.WriteLine("==================================================");

                int chon = InputHelper.NhapSoNguyen("Chọn chương: ", 0, dsChuong.Length);
                if (chon == 0) break;

                MenuChuong(dsChuong[chon - 1]);
            }

            Console.WriteLine("Tạm biệt!");
        }

        static void MenuChuong(Chuong chuong)
        {
            while (true)
            {
                XoaManHinh();
                Console.WriteLine($"========== {chuong.Ten.ToUpper()} ==========");
                for (int i = 0; i < chuong.DsBai.Length; i++)
                    Console.WriteLine($"{i + 1}. {chuong.DsBai[i].Ten}");
                Console.WriteLine("0. Quay lại");
                Console.WriteLine("==================================================");

                int chon = InputHelper.NhapSoNguyen("Chọn bài: ", 0, chuong.DsBai.Length);
                if (chon == 0) return;

                Bai bai = chuong.DsBai[chon - 1];
                XoaManHinh();
                Console.WriteLine($"----- {bai.Ten} -----\n");

                try
                {
                    bai.Chay();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"\n[Lỗi] {ex.Message}");
                }

                Console.WriteLine("\nNhấn Enter để quay lại menu...");
                Console.ReadLine();
            }
        }

        static void XoaManHinh()
        {
            if (!Console.IsOutputRedirected)
                Console.Clear();
        }
    }
}