using System;

namespace OOP_CSharp.Utils
{
    public static class InputHelper
    {
        // Nhập số nguyên, bắt nhập lại nếu sai định dạng hoặc ngoài khoảng [min, max]
        public static int NhapSoNguyen(string thongBao, int min = int.MinValue, int max = int.MaxValue)
        {
            while (true)
            {
                Console.Write(thongBao);
                if (int.TryParse(Console.ReadLine(), out int x) && x >= min && x <= max)
                    return x;

                if (min == int.MinValue && max == int.MaxValue)
                    Console.WriteLine("  -> Vui lòng nhập một số nguyên hợp lệ.");
                else
                    Console.WriteLine($"  -> Vui lòng nhập số nguyên từ {min} đến {max}.");
            }
        }

        // Nhập số thực (chấp nhận cả dấu . và dấu ,)
        public static double NhapSoThuc(string thongBao)
        {
            while (true)
            {
                Console.Write(thongBao);
                string s = (Console.ReadLine() ?? "").Replace(',', '.');
                if (double.TryParse(s, System.Globalization.NumberStyles.Float,
                                    System.Globalization.CultureInfo.InvariantCulture, out double x))
                    return x;

                Console.WriteLine("  -> Vui lòng nhập một số thực hợp lệ.");
            }
        }

        // Nhập chuỗi không được để trống
        public static string NhapChuoi(string thongBao)
        {
            while (true)
            {
                Console.Write(thongBao);
                string s = (Console.ReadLine() ?? "").Trim();
                if (s.Length > 0)
                    return s;

                Console.WriteLine("  -> Không được để trống.");
            }
        }
    }
}